﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        private static int[] PrintBoard(int[,] Board)
        {
            int[] Status = new int [2];
            Console.WriteLine("  A B C D E F G H");
            for(int i = 0; i < 8; i++)
            {
                Console.Write("{0} ", i + 1);
                for(int j = 0; j < 8; j++)
                {
                    if (Board[i, j] == 1)//為O
                    {
                        Console.Write("O ");
                        Status[0]++;
                    }
                    else if (Board[i, j] == 2)//為X
                    {
                        Console.Write("X ");
                        Status[1]++;
                    }
                    else//為空
                    {
                        Console.Write("- ");
                    }
                }
                Console.Write("\n");
            }
            return Status;
        }
        static void Main(string[] args)
        {
            int[,] Board = new int[8, 8];
            int[] Status;
            int Player = 1;//玩家一(O)先手
            int Count = 0;//盤面上棋子數量
            while(Count < 64)
            {
                try
                {
                    Console.Clear();
                    Status = PrintBoard(Board);
                    Console.WriteLine("輪到玩家{0} 請輸入要下的位置：", Player == 1 ? "O" : "X");
                    String Loc = Console.ReadLine();//玩家要下棋的位置
                    int LocX = (int)Loc[0] - 65;//將A-H 轉成0-7
                    int LocY = (int)Loc[1] - 49;
                    if (Board[LocY, LocX] == 0)
                    {
                        Board[LocY, LocX] = Player;
                        int HorMin = -1, HorMax = -1; //橫向中 為玩家棋子的最左與最右
                        int VerMin = -1, VerMax = -1; //直向中 為玩家棋子的最左與最右
                        for (int i = 0; i < 8; i++)//檢查兩方向中玩家己方棋子的上下、左右邊界
                        {
                            if (Board[LocY, i] == Player)//檢查水平
                            {
                                HorMin = HorMin == -1 ? i : HorMin; //若min ==-1 update else 不動
                                HorMax = i;
                            }
                            if (Board[i, LocX] == Player)//檢查垂直
                            {
                                VerMin = VerMin == -1 ? i : VerMin; //若min ==-1 update else 不動
                                VerMax = i;
                            }
                        }
                        Console.WriteLine("VER:{0},{1}", VerMin, VerMax);
                        Console.WriteLine("HOR:{0},{1}", HorMin, HorMax);
                        for (int i = HorMin; i <= HorMax; i++)
                        {
                            Board[LocY, i] = Board[LocY, i] == 0 ? 0 : Player;
                        }
                        for (int i = VerMin; i <= VerMax; i++)
                        {
                            Board[i, LocX] = Board[i, LocX] == 0 ? 0 : Player;
                        }
                        Status = PrintBoard(Board);
                        Player = Player == 1 ? 2 : 1;
                        Count = Status[0] + Status[1];
                    }
                    else
                    {
                        Console.WriteLine("此位置已有棋子！ 按任意繼續遊戲");
                        Console.ReadKey();
                        continue;
                    }
                }
                catch
                {
                    continue;
                }
            }
            Console.Clear();
            Status = PrintBoard(Board);
            Console.WriteLine("遊戲結束 玩家{0}獲勝！", Status[0]>Status[1]? "O":"X");
            Console.ReadKey();
        }
    }
}
