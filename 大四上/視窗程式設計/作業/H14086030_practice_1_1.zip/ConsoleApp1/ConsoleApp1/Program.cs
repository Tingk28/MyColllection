﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int Income=0, Expense=0, command=0;
            int balance = Income - Expense;
            int [] ExpenseList = new int[5];

            while (command != 5)
            {
                Console.WriteLine("(1)輸入收入(2)輸入支出(3)計算比例(4)剩餘金額(5)退出程式");
                Console.Write("輸入數字選擇功能：");
                command = Convert.ToInt32(Console.ReadLine());


                if (command == 1) //輸入收入
                {
                    Console.Write("輸入金額：");
                    Income += Convert.ToInt32(Console.ReadLine());
                }
                else if (command == 2)//輸入支出
                {
                    Console.WriteLine("(1)食 (2)衣 (3)住 (4)行 (5)育樂");
                    Console.Write("輸入數字選擇支出項目：");
                    int ExpenseType = Convert.ToInt32(Console.ReadLine());
                    Console.Write("輸入支出金額：");
                    int TempExpense = Convert.ToInt32(Console.ReadLine());
                    ExpenseList[ExpenseType-1] += TempExpense;
                    Expense += TempExpense;
                }

                else if (command == 3)//計算比例
                {
                    string[] ExpenseName = new string[] { "食", "衣", "住", "行", "育樂" };
                    for(int i =0; i < 5; i++)
                    {
                        Console.WriteLine("{0}： {1}%", ExpenseName[i], Expense==0? 0:(double)ExpenseList[i] * 100 / (double)Expense);
                    }
                }

                else if (command == 4)//剩餘金額
                {
                    balance = Income - Expense;
                    Console.WriteLine("剩餘金額為：{0}", balance);
                    
                }
                Console.Write("\n");
            }
            
        }
    }
}
