﻿namespace CardGame1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_cont = new System.Windows.Forms.Button();
            this.btn_quit = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_restart = new System.Windows.Forms.Button();
            this.score = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.username_box = new System.Windows.Forms.TextBox();
            this.rank_box = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "翻牌小遊戲";
            // 
            // btn_start
            // 
            this.btn_start.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_start.Location = new System.Drawing.Point(531, 58);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(115, 61);
            this.btn_start.TabIndex = 1;
            this.btn_start.Text = "開始遊戲";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_cont
            // 
            this.btn_cont.Enabled = false;
            this.btn_cont.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_cont.Location = new System.Drawing.Point(531, 136);
            this.btn_cont.Name = "btn_cont";
            this.btn_cont.Size = new System.Drawing.Size(115, 61);
            this.btn_cont.TabIndex = 1;
            this.btn_cont.Text = "繼續";
            this.btn_cont.UseVisualStyleBackColor = true;
            this.btn_cont.Click += new System.EventHandler(this.btn_cont_Click);
            // 
            // btn_quit
            // 
            this.btn_quit.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_quit.Location = new System.Drawing.Point(531, 420);
            this.btn_quit.Name = "btn_quit";
            this.btn_quit.Size = new System.Drawing.Size(115, 61);
            this.btn_quit.TabIndex = 1;
            this.btn_quit.Text = "離開遊戲";
            this.btn_quit.UseVisualStyleBackColor = true;
            this.btn_quit.Click += new System.EventHandler(this.btn_quit_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(18, 48);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(666, 531);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.username_box);
            this.tabPage1.Controls.Add(this.username);
            this.tabPage1.Controls.Add(this.score);
            this.tabPage1.Controls.Add(this.btn_start);
            this.tabPage1.Controls.Add(this.btn_quit);
            this.tabPage1.Controls.Add(this.btn_restart);
            this.tabPage1.Controls.Add(this.btn_cont);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(658, 505);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "遊玩區";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.rank_box);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(658, 505);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "歷史紀錄區";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btn_restart
            // 
            this.btn_restart.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_restart.Location = new System.Drawing.Point(531, 216);
            this.btn_restart.Name = "btn_restart";
            this.btn_restart.Size = new System.Drawing.Size(115, 61);
            this.btn_restart.TabIndex = 1;
            this.btn_restart.Text = "重新開始";
            this.btn_restart.UseVisualStyleBackColor = true;
            this.btn_restart.Click += new System.EventHandler(this.btn_restart_Click);
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Font = new System.Drawing.Font("新細明體", 12F);
            this.score.Location = new System.Drawing.Point(22, 22);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(80, 16);
            this.score.TabIndex = 2;
            this.score.Text = "分數：100";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("新細明體", 12F);
            this.username.Location = new System.Drawing.Point(140, 22);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(56, 16);
            this.username.TabIndex = 2;
            this.username.Text = "名稱：";
            // 
            // username_box
            // 
            this.username_box.Font = new System.Drawing.Font("新細明體", 12F);
            this.username_box.Location = new System.Drawing.Point(202, 19);
            this.username_box.Name = "username_box";
            this.username_box.Size = new System.Drawing.Size(170, 27);
            this.username_box.TabIndex = 3;
            // 
            // rank_box
            // 
            this.rank_box.Location = new System.Drawing.Point(32, 21);
            this.rank_box.Multiline = true;
            this.rank_box.Name = "rank_box";
            this.rank_box.ReadOnly = true;
            this.rank_box.Size = new System.Drawing.Size(603, 464);
            this.rank_box.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 591);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_cont;
        private System.Windows.Forms.Button btn_quit;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox username_box;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Button btn_restart;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox rank_box;
    }
}

