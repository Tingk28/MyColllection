﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardGame1
{
    public partial class Form1 : Form
    {
        ID_Button[] buttons = new ID_Button[16];
        Image[] Imagelib = new Image[9];
        int points = 100;
        List<int> Card_filp = new List<int>();//紀錄正在翻起的牌
        int[] Ans = new int[] { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7 };
        public static void Shuffle(int [] ans)
        {
            Random rnd = new Random();
            for(int i =0; i < 30; i++){//將ans array隨意交換50次以達到隨機的效果
                int j = rnd.Next(16);
                int k = rnd.Next(16);
                int temp = ans[k];
                ans[k] = ans[j];
                ans[j] = temp;
            }
        }
        public Form1()
        {
            InitializeComponent();
            for(int i=0; i < 8; i++)
            {
                String loc = string.Format(@"..\..\images\0{0}.jpg", i + 1);
                Console.WriteLine(loc);
                Imagelib[i] = Image.FromFile(loc);
            }
            Imagelib[8] = Image.FromFile(@"..\..\images\card.jpg");
            Shuffle(Ans);
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            if (username_box.Text == "")//空白
            {
                MessageBox.Show("名稱不能為空白", "錯誤", MessageBoxButtons.OK,MessageBoxIcon.Error);

            }
            else if (username_box.Text.Length<3 || username_box.Text.Length >10)
            {
                MessageBox.Show("名稱不合格式（>=3 && <=10）", "錯誤", MessageBoxButtons.OK,MessageBoxIcon.Error);

            }
            else//使用者名稱符合格式
            {
                username_box.Enabled = false;
                for (int i = 0; i < 16; i++)
                {
                    buttons[i] = new ID_Button(i);
                    buttons[i].SetBounds(30 + (130 * (i % 4)), 55 + 110 * (i / 4), 70, 100);
                    buttons[i].Image = Imagelib[8];
                    buttons[i].Click += new System.EventHandler(this.Card_Click);
                    tabPage1.Controls.Add(buttons[i]);
                }
                btn_start.Enabled = false;
            }
            
        }
        private void Card_Click(object sender, EventArgs e)
        {
            ID_Button btn = sender as ID_Button;
            int btn_id = btn.Get_ID();

            if (Card_filp.Count() != 2)//已經翻滿兩張 不能再翻牌 需要按繼續紐
            {
                Card_filp.Add(btn_id);
                buttons[btn_id].Enabled = false;
                buttons[btn_id].Image = Imagelib[Ans[btn_id]];
            }

            if(Card_filp.Count() == 2)//已經翻兩張了
            {
                if (Ans[Card_filp[0]] == Ans[Card_filp[1]])//答對了
                {
                    Card_filp.Clear();
                    points += 10;
                    score.Text = string.Format("分數：{0}", points);
                    for(int i = 0; i < 16; i++)//檢查勝利條件
                    {
                        if (buttons[i].Enabled)
                        {
                            break;
                        }
                        if (i == 15)
                        {
                            rank_box.Text += string.Format("{0} 得分為：{1}\r\n\r\n", username_box.Text, points);
                            DialogResult result;
                            result = MessageBox.Show(score.Text.Replace("：",": "), "遊戲結束",MessageBoxButtons.RetryCancel,MessageBoxIcon.Asterisk);
                            if (result == DialogResult.Retry)
                            {
                                btn_restart_Click(null,null);
                            }
                        }
                    }
                }
                else
                {//答錯了
                    btn_cont.Enabled = true;
                    points -= 5;
                    score.Text = string.Format("分數：{0}", points);
                }
            }
        }

        private void btn_cont_Click(object sender, EventArgs e)
        {
            buttons[Card_filp[0]].Image = Imagelib[8];
            buttons[Card_filp[0]].Enabled = true;
            buttons[Card_filp[1]].Image = Imagelib[8];
            buttons[Card_filp[1]].Enabled = true;
            Card_filp.Clear();
            btn_cont.Enabled = false;
        }

        private void btn_quit_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("確定要離開遊戲嘛？", "離開遊戲", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if(result == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void btn_restart_Click(object sender, EventArgs e)
        {
            if (btn_start.Enabled == false)//遊戲已經開始
            {
                foreach (ID_Button i in buttons) { tabPage1.Controls.Remove(i); }
                points = 100;
                username_box.Enabled = true;
                username_box.Text = "";
                score.Text = string.Format("分數：{0}", points);
                btn_start.Enabled = true;
                btn_cont.Enabled = false;
                Card_filp.Clear();
                Shuffle(Ans);//打散答案
            }
            username_box.Text = "";

        }
    }
}
