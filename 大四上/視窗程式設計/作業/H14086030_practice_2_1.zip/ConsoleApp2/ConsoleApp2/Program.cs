﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Credit = 0, command = 0;
            string[,] Sheet = new string[8, 7];//七天八節課
            String[] ID = new string[1];//儲存所有編號
            while (command != 5)
            {
                Console.WriteLine("(1)新增課程 (2)刪除課程 (3)列印課表 (4)計算學分 (5)離開程式");
                Console.Write("請輸入數字選擇功能：");
                command = Convert.ToInt32(Console.ReadLine());
                if(command == 1)//新增課程
                {
                    Console.WriteLine("請輸入要加入的課程，格式為<課程代號 星期 開始節 結束節>");
                    String CourseInfo = Console.ReadLine();
                    String [] SplitInfo = CourseInfo.Split(' ');
                    int Day = Convert.ToInt32(SplitInfo[1])%7;//星期幾
                    int Start = Convert.ToInt32(SplitInfo[2])-1;//開始節
                    int End = Convert.ToInt32(SplitInfo[3])-1;//結束節
                    if (Array.IndexOf(ID, SplitInfo[0]) == -1){//已經有這門課

                        Boolean HaveClass = false;
                        for (int i = Start; i <= End; i++)
                        {
                            if(Sheet[i, Day] != null)//檢查衝堂
                            {
                                Console.WriteLine("課程衝堂！");
                                HaveClass = true;
                                break;
                            }
                        }
                        if (!HaveClass)//如果沒有衝堂
                        {
                            for (int i = Start; i <= End; i++)
                            {
                                Sheet[i, Day] = SplitInfo[0];
                            }

                            ID[ID.GetLength(0) - 1] = SplitInfo[0];//最後一格加入編號
                            Array.Resize(ref ID, ID.GetLength(0) + 1);//儲存編號array長度+1
                            Credit += End - Start + 1;
                            Console.WriteLine("成功加入課程！");
                        }
                    }
                    else
                    {
                        Console.WriteLine("課程重複！");
                    }
                    
                }
                else if(command == 2)//刪除課程
                {
                    Console.Write("請輸入要刪除的課程代號：");
                    String DelID = Console.ReadLine();
                    if(Array.IndexOf(ID, DelID) != -1)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            for (int j = 0; j < 7; j++)
                            {
                                if(Sheet[i, j] == DelID)
                                {
                                    Sheet[i, j] = null;
                                    Credit--;
                                }
                            }
                        }
                        int DelLoc = Array.IndexOf(ID, DelID);//要刪除的課程在ID的哪個位子
                        ID[DelLoc] = ID[ID.GetLength(0) - 1];//用最後一個課名取代欲刪除的代號
                        Array.Resize(ref ID, ID.GetLength(0) - 1);
                        Console.WriteLine("成功刪除課程：{0}",DelID);
                    }
                    else
                    {
                        Console.WriteLine("課程 {0} 不在課表中", DelID);
                    }
                }
                else if (command == 3)//列印課表
                {
                    Console.WriteLine("      Sun   Mon   Tue   Wed   Thu   Fri   Sat   ");
                    for (int i=0; i<8; i++)
                    {
                        Console.Write(String.Format("{0,-6}",i+1));
                        for(int j=0; j<7; j++)
                        {
                            Console.Write("{0,-6}", Sheet[i, j]);
                        }
                        Console.WriteLine("");
                    }
                    
                }
                else if (command == 4)//計算學分
                {
                    Console.WriteLine(Credit);
                }
                Console.WriteLine("");
            }
        }
    }
}
