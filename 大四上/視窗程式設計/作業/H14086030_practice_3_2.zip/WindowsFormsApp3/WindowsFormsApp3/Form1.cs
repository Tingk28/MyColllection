﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        private List<Stack> GameStack = new List<Stack>();
        private List<TextBox> inputbox = new List<TextBox>();
        private List<Label> ingamestack = new List<Label>();
        private List<Button> btn_Stacks = new List<Button>();

        private int taking = 0;//現在正在拿取的stack
        public Form1()
        {
            InitializeComponent();
            //建立inputbox list
            inputbox.Add(stack1input);
            inputbox.Add(stack2input);
            inputbox.Add(stack3input);
            inputbox.Add(stack4input);
            //建立label list 遊戲畫面中顯示stack用
            ingamestack.Add(stack1_game);
            ingamestack.Add(stack2_game);
            ingamestack.Add(stack3_game);
            ingamestack.Add(stack4_game);
            //建立buttom list
            btn_Stacks.Add(btn_stack1);
            btn_Stacks.Add(btn_stack2);
            btn_Stacks.Add(btn_stack3);
            btn_Stacks.Add(btn_stack4);
        }
        
        private void btn_gamestart_Click(object sender, EventArgs e)
        {
            TextBox[] inputbox = new TextBox[] { stack1input, stack2input, stack3input, stack4input };
            Label[] ingamestack = new Label[] { stack1_game, stack2_game, stack3_game, stack4_game };
            //Console.Clear();
            bool dataok = true; //測資是否有問題
            int[] numbercount = new int[] { 0, 0, 0 };
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    String temp = inputbox[i].Text;
                    if (temp == "") continue;
                    String[] tempsplit = temp.Split(' ');
                    //int a = Convert.ToInt32(temp[0]);
                    //Console.WriteLine("split len:{0}",tempsplit.GetLength(0));
                    if (tempsplit.GetLength(0) > 4)//檢查stack有沒有大於4
                    {
                        Console.WriteLine("測資過長");
                        throw new ArgumentException();
                    }
                    for (int j = 0; j < tempsplit.GetLength(0); j++)
                    {
                        if (tempsplit[j].Length != 1)//字元間沒有用空格隔開
                        {
                            Console.WriteLine("字元間請用空格隔開");
                            throw new ArgumentException();
                        }
                        int tempadd = (int)tempsplit[j][0] - 48;//ASCII to int
                        Console.WriteLine(tempadd);
                        if (tempadd > 3 || tempadd < 0)//if 輸入的字元非 1 2 3
                        {
                            Console.WriteLine("請輸入1-3");
                            throw new ArgumentException();
                        }
                        else//通過一切檢查 
                        {
                            numbercount[tempadd - 1]++;
                        }
                    }
                    //Console.WriteLine("numbercount:{0}", string.Join(",", numbercount));
                }
                foreach (int i in numbercount) if (i != 3) throw new ArgumentException();
            }
            catch
            {
                statusbar1.Text = "測資錯誤";
                dataok = false;
            }
            
            if (dataok)
            {
                //隱藏建立選單
                statusbar1.Visible = false;
                label_data1.Visible = false;
                label_data2.Visible = false;
                label_data3.Visible = false;
                label_data4.Visible = false;
                btn_gamestart.Visible = false;
                stack1input.Visible = false;
                stack2input.Visible = false;
                stack3input.Visible = false;
                stack4input.Visible = false;



                //顯示遊戲介面
                label_data1_1.Visible = true;
                label_data2_1.Visible = true;
                label_data3_1.Visible = true;
                label_data4_1.Visible = true;
                stack1_game.Visible = true;
                stack2_game.Visible = true;
                stack3_game.Visible = true;
                stack4_game.Visible = true;
                statusbar2.Visible = true;
                btn_goback.Visible = true;
                btn_stack1.Visible = true;
                btn_stack2.Visible = true;
                btn_stack3.Visible = true;
                btn_stack4.Visible = true;

                
                for (int i = 0; i < 4; i++)
                {
                    Stack tempstack = new Stack(inputbox[i].Text);//將數字加到stack中
                    GameStack.Add(tempstack);
                    ingamestack[i].Text = GameStack[i].ToString();
                }
                check_and_update();
                /*for (int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Enabled = GameStack[i].cantake();
                }*/

            }//資料完全沒有問題 開始遊戲




        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(taking))//如果有正在拿取的stack
            {
                int temp = GameStack[taking-1].pop();
                GameStack[0].push(temp);
                taking = 0;
                check_and_update();
            }
            else//沒有正在拿取的stack
            {
                taking = 1;
                statusbar2.Text = string.Format("你選擇了堆疊{0}", taking);
                for(int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Text = "放置";
                    btn_Stacks[i].Enabled = GameStack[i].canplace();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(taking))//如果有正在拿取的stack
            {
                int temp = GameStack[taking - 1].pop();
                GameStack[1].push(temp);
                taking = 0;
                check_and_update();
            }
            else//沒有正在拿取的stack
            {
                taking = 2;
                statusbar2.Text = string.Format("你選擇了堆疊{0}", taking);
                for (int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Text = "放置";
                    btn_Stacks[i].Enabled = GameStack[i].canplace();
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(taking))//如果有正在拿取的stack
            {
                int temp = GameStack[taking - 1].pop();
                GameStack[2].push(temp);
                taking = 0;
                check_and_update();
            }
            else//沒有正在拿取的stack
            {
                taking = 3;
                statusbar2.Text = string.Format("你選擇了堆疊{0}", taking);
                for (int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Text = "放置";
                    btn_Stacks[i].Enabled = GameStack[i].canplace();
                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(taking))//如果有正在拿取的stack
            {
                int temp = GameStack[taking - 1].pop();
                GameStack[3].push(temp);
                taking = 0;
                check_and_update();
            }
            else//沒有正在拿取的stack
            {
                taking = 4;
                statusbar2.Text = string.Format("你選擇了堆疊{0}", taking);
                for (int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Text = "放置";
                    btn_Stacks[i].Enabled = GameStack[i].canplace();
                }
            }
        }

        private void btn_goback_Click(object sender, EventArgs e)
        {
            //顯示建立選單
            statusbar1.Visible = true;
            label_data1.Visible = true;
            label_data2.Visible = true;
            label_data3.Visible = true;
            label_data4.Visible = true;
            btn_gamestart.Visible = true;
            stack1input.Visible = true;
            stack2input.Visible = true;
            stack3input.Visible = true;
            stack4input.Visible = true;


            //建立遊戲介面
            label_data1_1.Visible = false;
            label_data2_1.Visible = false;
            label_data3_1.Visible = false;
            label_data4_1.Visible = false;
            stack1_game.Visible = false;
            stack2_game.Visible = false;
            stack3_game.Visible = false;
            stack4_game.Visible = false;
            statusbar2.Visible = false;
            btn_goback.Visible = false;
            btn_stack1.Visible = false;
            btn_stack2.Visible = false;
            btn_stack3.Visible = false;
            btn_stack4.Visible = false;

            GameStack.Clear();

            statusbar1.Text = "請輸入測資";

            inputbox[0].Text = "1 1 2";
            inputbox[1].Text = "2 2";
            inputbox[2].Text = "";
            inputbox[3].Text = "3 3 3 1";


        }
        private void check_and_update()//每次放置後更新內容
        {
            for (int i = 0; i < 4; i++)
            {
                btn_Stacks[i].Text = "選取";
                btn_Stacks[i].Enabled = GameStack[i].cantake();
                ingamestack[i].Text = GameStack[i].ToString();
            }
            statusbar2.Text = "'''";

            int winning_point = 0;
            foreach (Stack i in GameStack) { winning_point += i.Finished(); }
            if (winning_point == 3)
            {
                for (int i = 0; i < 4; i++)
                {
                    btn_Stacks[i].Text = "贏";
                    btn_Stacks[i].Enabled = false;
                }
                statusbar2.Text = "你贏了";
            }
        }
    }
}
