﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_data1 = new System.Windows.Forms.Label();
            this.label_data2 = new System.Windows.Forms.Label();
            this.label_data3 = new System.Windows.Forms.Label();
            this.label_data4 = new System.Windows.Forms.Label();
            this.stack1input = new System.Windows.Forms.TextBox();
            this.stack2input = new System.Windows.Forms.TextBox();
            this.stack4input = new System.Windows.Forms.TextBox();
            this.stack3input = new System.Windows.Forms.TextBox();
            this.btn_gamestart = new System.Windows.Forms.Button();
            this.statusbar1 = new System.Windows.Forms.TextBox();
            this.label_data4_1 = new System.Windows.Forms.Label();
            this.label_data3_1 = new System.Windows.Forms.Label();
            this.label_data2_1 = new System.Windows.Forms.Label();
            this.label_data1_1 = new System.Windows.Forms.Label();
            this.btn_stack1 = new System.Windows.Forms.Button();
            this.btn_stack2 = new System.Windows.Forms.Button();
            this.btn_stack3 = new System.Windows.Forms.Button();
            this.btn_stack4 = new System.Windows.Forms.Button();
            this.statusbar2 = new System.Windows.Forms.TextBox();
            this.btn_goback = new System.Windows.Forms.Button();
            this.stack1_game = new System.Windows.Forms.Label();
            this.stack2_game = new System.Windows.Forms.Label();
            this.stack3_game = new System.Windows.Forms.Label();
            this.stack4_game = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_data1
            // 
            this.label_data1.AutoSize = true;
            this.label_data1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data1.Location = new System.Drawing.Point(73, 145);
            this.label_data1.Name = "label_data1";
            this.label_data1.Size = new System.Drawing.Size(56, 19);
            this.label_data1.TabIndex = 0;
            this.label_data1.Text = "堆疊1";
            // 
            // label_data2
            // 
            this.label_data2.AutoSize = true;
            this.label_data2.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data2.Location = new System.Drawing.Point(73, 203);
            this.label_data2.Name = "label_data2";
            this.label_data2.Size = new System.Drawing.Size(56, 19);
            this.label_data2.TabIndex = 2;
            this.label_data2.Text = "堆疊2";
            // 
            // label_data3
            // 
            this.label_data3.AutoSize = true;
            this.label_data3.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data3.Location = new System.Drawing.Point(73, 257);
            this.label_data3.Name = "label_data3";
            this.label_data3.Size = new System.Drawing.Size(56, 19);
            this.label_data3.TabIndex = 3;
            this.label_data3.Text = "堆疊3";
            // 
            // label_data4
            // 
            this.label_data4.AutoSize = true;
            this.label_data4.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data4.Location = new System.Drawing.Point(73, 311);
            this.label_data4.Name = "label_data4";
            this.label_data4.Size = new System.Drawing.Size(56, 19);
            this.label_data4.TabIndex = 4;
            this.label_data4.Text = "堆疊4";
            // 
            // stack1input
            // 
            this.stack1input.Font = new System.Drawing.Font("新細明體", 14F);
            this.stack1input.Location = new System.Drawing.Point(153, 142);
            this.stack1input.Name = "stack1input";
            this.stack1input.Size = new System.Drawing.Size(247, 30);
            this.stack1input.TabIndex = 1;
            this.stack1input.Text = "1 1 2";
            // 
            // stack2input
            // 
            this.stack2input.Font = new System.Drawing.Font("新細明體", 14F);
            this.stack2input.Location = new System.Drawing.Point(153, 200);
            this.stack2input.Name = "stack2input";
            this.stack2input.Size = new System.Drawing.Size(247, 30);
            this.stack2input.TabIndex = 2;
            this.stack2input.Text = "2 2";
            // 
            // stack4input
            // 
            this.stack4input.Font = new System.Drawing.Font("新細明體", 14F);
            this.stack4input.Location = new System.Drawing.Point(153, 308);
            this.stack4input.Name = "stack4input";
            this.stack4input.Size = new System.Drawing.Size(247, 30);
            this.stack4input.TabIndex = 4;
            this.stack4input.Text = "3 3 3 1";
            // 
            // stack3input
            // 
            this.stack3input.Font = new System.Drawing.Font("新細明體", 14F);
            this.stack3input.Location = new System.Drawing.Point(153, 254);
            this.stack3input.Name = "stack3input";
            this.stack3input.Size = new System.Drawing.Size(247, 30);
            this.stack3input.TabIndex = 3;
            // 
            // btn_gamestart
            // 
            this.btn_gamestart.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_gamestart.Location = new System.Drawing.Point(187, 365);
            this.btn_gamestart.Name = "btn_gamestart";
            this.btn_gamestart.Size = new System.Drawing.Size(112, 36);
            this.btn_gamestart.TabIndex = 6;
            this.btn_gamestart.Text = "開始遊戲";
            this.btn_gamestart.UseVisualStyleBackColor = true;
            this.btn_gamestart.Click += new System.EventHandler(this.btn_gamestart_Click);
            // 
            // statusbar1
            // 
            this.statusbar1.Font = new System.Drawing.Font("新細明體", 14F);
            this.statusbar1.Location = new System.Drawing.Point(77, 68);
            this.statusbar1.Name = "statusbar1";
            this.statusbar1.ReadOnly = true;
            this.statusbar1.Size = new System.Drawing.Size(323, 30);
            this.statusbar1.TabIndex = 7;
            this.statusbar1.Text = "請輸入測資";
            // 
            // label_data4_1
            // 
            this.label_data4_1.AutoSize = true;
            this.label_data4_1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data4_1.Location = new System.Drawing.Point(407, 46);
            this.label_data4_1.Name = "label_data4_1";
            this.label_data4_1.Size = new System.Drawing.Size(56, 19);
            this.label_data4_1.TabIndex = 11;
            this.label_data4_1.Text = "堆疊4";
            this.label_data4_1.Visible = false;
            // 
            // label_data3_1
            // 
            this.label_data3_1.AutoSize = true;
            this.label_data3_1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data3_1.Location = new System.Drawing.Point(292, 46);
            this.label_data3_1.Name = "label_data3_1";
            this.label_data3_1.Size = new System.Drawing.Size(56, 19);
            this.label_data3_1.TabIndex = 10;
            this.label_data3_1.Text = "堆疊3";
            this.label_data3_1.Visible = false;
            // 
            // label_data2_1
            // 
            this.label_data2_1.AutoSize = true;
            this.label_data2_1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data2_1.Location = new System.Drawing.Point(174, 46);
            this.label_data2_1.Name = "label_data2_1";
            this.label_data2_1.Size = new System.Drawing.Size(56, 19);
            this.label_data2_1.TabIndex = 9;
            this.label_data2_1.Text = "堆疊2";
            this.label_data2_1.Visible = false;
            // 
            // label_data1_1
            // 
            this.label_data1_1.AutoSize = true;
            this.label_data1_1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_data1_1.Location = new System.Drawing.Point(73, 46);
            this.label_data1_1.Name = "label_data1_1";
            this.label_data1_1.Size = new System.Drawing.Size(56, 19);
            this.label_data1_1.TabIndex = 8;
            this.label_data1_1.Text = "堆疊1";
            this.label_data1_1.Visible = false;
            // 
            // btn_stack1
            // 
            this.btn_stack1.Font = new System.Drawing.Font("新細明體", 9F);
            this.btn_stack1.Location = new System.Drawing.Point(77, 343);
            this.btn_stack1.Name = "btn_stack1";
            this.btn_stack1.Size = new System.Drawing.Size(52, 36);
            this.btn_stack1.TabIndex = 13;
            this.btn_stack1.Text = "選取";
            this.btn_stack1.UseVisualStyleBackColor = true;
            this.btn_stack1.Visible = false;
            this.btn_stack1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_stack2
            // 
            this.btn_stack2.Font = new System.Drawing.Font("新細明體", 9F);
            this.btn_stack2.Location = new System.Drawing.Point(178, 343);
            this.btn_stack2.Name = "btn_stack2";
            this.btn_stack2.Size = new System.Drawing.Size(52, 36);
            this.btn_stack2.TabIndex = 13;
            this.btn_stack2.Text = "選取";
            this.btn_stack2.UseVisualStyleBackColor = true;
            this.btn_stack2.Visible = false;
            this.btn_stack2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_stack3
            // 
            this.btn_stack3.Font = new System.Drawing.Font("新細明體", 9F);
            this.btn_stack3.Location = new System.Drawing.Point(296, 343);
            this.btn_stack3.Name = "btn_stack3";
            this.btn_stack3.Size = new System.Drawing.Size(52, 36);
            this.btn_stack3.TabIndex = 13;
            this.btn_stack3.Text = "選取";
            this.btn_stack3.UseVisualStyleBackColor = true;
            this.btn_stack3.Visible = false;
            this.btn_stack3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_stack4
            // 
            this.btn_stack4.Font = new System.Drawing.Font("新細明體", 9F);
            this.btn_stack4.Location = new System.Drawing.Point(406, 344);
            this.btn_stack4.Name = "btn_stack4";
            this.btn_stack4.Size = new System.Drawing.Size(52, 36);
            this.btn_stack4.TabIndex = 13;
            this.btn_stack4.Text = "選取";
            this.btn_stack4.UseVisualStyleBackColor = true;
            this.btn_stack4.Visible = false;
            this.btn_stack4.Click += new System.EventHandler(this.button4_Click);
            // 
            // statusbar2
            // 
            this.statusbar2.Font = new System.Drawing.Font("新細明體", 14F);
            this.statusbar2.Location = new System.Drawing.Point(77, 398);
            this.statusbar2.Name = "statusbar2";
            this.statusbar2.ReadOnly = true;
            this.statusbar2.Size = new System.Drawing.Size(202, 30);
            this.statusbar2.TabIndex = 7;
            this.statusbar2.Text = "\'\'\'";
            this.statusbar2.Visible = false;
            // 
            // btn_goback
            // 
            this.btn_goback.Font = new System.Drawing.Font("新細明體", 14F);
            this.btn_goback.Location = new System.Drawing.Point(296, 391);
            this.btn_goback.Name = "btn_goback";
            this.btn_goback.Size = new System.Drawing.Size(167, 37);
            this.btn_goback.TabIndex = 14;
            this.btn_goback.Text = "回主畫面";
            this.btn_goback.UseVisualStyleBackColor = true;
            this.btn_goback.Visible = false;
            this.btn_goback.Click += new System.EventHandler(this.btn_goback_Click);
            // 
            // stack1_game
            // 
            this.stack1_game.BackColor = System.Drawing.SystemColors.Window;
            this.stack1_game.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stack1_game.ForeColor = System.Drawing.Color.Black;
            this.stack1_game.Location = new System.Drawing.Point(77, 98);
            this.stack1_game.Name = "stack1_game";
            this.stack1_game.Size = new System.Drawing.Size(52, 218);
            this.stack1_game.TabIndex = 15;
            this.stack1_game.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.stack1_game.Visible = false;
            // 
            // stack2_game
            // 
            this.stack2_game.BackColor = System.Drawing.SystemColors.Window;
            this.stack2_game.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stack2_game.ForeColor = System.Drawing.Color.Black;
            this.stack2_game.Location = new System.Drawing.Point(178, 98);
            this.stack2_game.Name = "stack2_game";
            this.stack2_game.Size = new System.Drawing.Size(52, 218);
            this.stack2_game.TabIndex = 15;
            this.stack2_game.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.stack2_game.Visible = false;
            // 
            // stack3_game
            // 
            this.stack3_game.BackColor = System.Drawing.SystemColors.Window;
            this.stack3_game.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stack3_game.ForeColor = System.Drawing.Color.Black;
            this.stack3_game.Location = new System.Drawing.Point(296, 98);
            this.stack3_game.Name = "stack3_game";
            this.stack3_game.Size = new System.Drawing.Size(52, 218);
            this.stack3_game.TabIndex = 15;
            this.stack3_game.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.stack3_game.Visible = false;
            // 
            // stack4_game
            // 
            this.stack4_game.BackColor = System.Drawing.SystemColors.Window;
            this.stack4_game.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stack4_game.ForeColor = System.Drawing.Color.Black;
            this.stack4_game.Location = new System.Drawing.Point(411, 98);
            this.stack4_game.Name = "stack4_game";
            this.stack4_game.Size = new System.Drawing.Size(52, 218);
            this.stack4_game.TabIndex = 15;
            this.stack4_game.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.stack4_game.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 467);
            this.Controls.Add(this.btn_goback);
            this.Controls.Add(this.btn_stack4);
            this.Controls.Add(this.btn_stack3);
            this.Controls.Add(this.btn_stack2);
            this.Controls.Add(this.btn_stack1);
            this.Controls.Add(this.label_data4_1);
            this.Controls.Add(this.label_data3_1);
            this.Controls.Add(this.label_data2_1);
            this.Controls.Add(this.label_data1_1);
            this.Controls.Add(this.statusbar2);
            this.Controls.Add(this.statusbar1);
            this.Controls.Add(this.btn_gamestart);
            this.Controls.Add(this.stack4input);
            this.Controls.Add(this.stack2input);
            this.Controls.Add(this.stack1input);
            this.Controls.Add(this.label_data4);
            this.Controls.Add(this.label_data3);
            this.Controls.Add(this.label_data2);
            this.Controls.Add(this.label_data1);
            this.Controls.Add(this.stack3input);
            this.Controls.Add(this.stack4_game);
            this.Controls.Add(this.stack3_game);
            this.Controls.Add(this.stack2_game);
            this.Controls.Add(this.stack1_game);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_data1;
        private System.Windows.Forms.Label label_data2;
        private System.Windows.Forms.Label label_data3;
        private System.Windows.Forms.Label label_data4;
        private System.Windows.Forms.TextBox stack1input;
        private System.Windows.Forms.TextBox stack2input;
        private System.Windows.Forms.TextBox stack4input;
        private System.Windows.Forms.TextBox stack3input;
        private System.Windows.Forms.Button btn_gamestart;
        private System.Windows.Forms.TextBox statusbar1;
        private System.Windows.Forms.Label label_data4_1;
        private System.Windows.Forms.Label label_data3_1;
        private System.Windows.Forms.Label label_data2_1;
        private System.Windows.Forms.Label label_data1_1;
        private System.Windows.Forms.Button btn_stack1;
        private System.Windows.Forms.Button btn_stack2;
        private System.Windows.Forms.Button btn_stack3;
        private System.Windows.Forms.Button btn_stack4;
        private System.Windows.Forms.TextBox statusbar2;
        private System.Windows.Forms.Button btn_goback;
        private System.Windows.Forms.Label stack1_game;
        private System.Windows.Forms.Label stack2_game;
        private System.Windows.Forms.Label stack3_game;
        private System.Windows.Forms.Label stack4_game;
    }
}

