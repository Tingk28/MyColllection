﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    class Stack 
    {
        private List<int> stack = new List<int>();
        private int index;// stack的最高位（長度）
        public bool canplace()//可不可以再放置
        {
            return index != 4;
        }
        public bool cantake()//能否拿取
        {
            return index != 0;
        }
        public void push(int i)
        {
            stack.Add(i);
            index++;
        }
        public int pop()
        {
            int temp = stack[index - 1];
            stack.RemoveAt(index-1);
            index--;
            return temp;
        }
        public String ToString()
        {
            stack.Reverse();
            String result = string.Join("\r\n", stack);
            stack.Reverse();
            return result;
        }
        public Stack(String input)
        {
            if(input == "")
            {
                index = 0;
            }
            else
            {
                String[] temp = input.Split(' ');
                for (int i = 0; i < temp.Length; i++)
                {
                    stack.Add((int)(temp[i][0])-48);
                    index = i + 1;
                }
            }
        }
        public int Finished()//回傳此stack是否已經"勝利"
        {
            if (index == 3 && stack[0] == stack[1] && stack[0] == stack[2] ) { return 1; } else { return 0; }
        }
    }
}
