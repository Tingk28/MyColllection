﻿/*INSERT INTO 員工編號_姓名_電子信箱(員工編號,姓名,電子信箱)VALUES ('F71234567','Lewis','lewis@csie.ncku.edu.tw')
INSERT INTO 員工編號_姓名_電子信箱(員工編號,姓名,電子信箱)VALUES ('F87654321','Eddie','eddie@csie.ncku.edu.tw')
INSERT INTO 員工編號_姓名_電子信箱(員工編號,姓名,電子信箱)VALUES ('H14086030',N'郭庭維','h14086030@gs.ncku.edu.tw')

INSERT INTO 電話_員工編號(電話,員工編號)VALUES ('0912345678','F71234567')
INSERT INTO 電話_員工編號(電話,員工編號)VALUES ('0987654321','F87654321')
INSERT INTO 電話_員工編號(電話,員工編號)VALUES ('0900000000','H14086030')

INSERT INTO 員工編號_薪水(員工編號,薪水)VALUES ('F71234567','100')
INSERT INTO 員工編號_薪水(員工編號,薪水)VALUES ('F87654321','65535')
INSERT INTO 員工編號_薪水(員工編號,薪水)VALUES ('H14086030','99999')

Select * from 員工編號_姓名_電子信箱
Select * from 電話_員工編號
Select * from 員工編號_薪水*/


/*update 員工編號_姓名_電子信箱 set 電子信箱 = 'hello@csie.ncku.edu.tw' where 員工編號 = 'F71234567'
update 電話_員工編號 set 電話 = '0977777777' where 員工編號 = 'F71234567'
update 員工編號_薪水 set 薪水 = '100000' where 員工編號 = 'F87654321'

SELECT 員工編號,電子信箱 from 員工編號_姓名_電子信箱
SELECT 電話,員工編號 from 電話_員工編號
SELECT 員工編號,薪水 from 員工編號_薪水*/

delete from 電話_員工編號 where 員工編號 = 'F71234567'

Select * from 員工編號_姓名_電子信箱 where 姓名 = 'Lewis'
Select * from 電話_員工編號 where 員工編號 = 'F71234567'
Select * from 員工編號_薪水 where 員工編號 = 'F71234567'

