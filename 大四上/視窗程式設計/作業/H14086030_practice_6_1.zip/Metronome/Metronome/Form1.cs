﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Metronome
{
    public partial class Form1 : Form
    {
        int time = 0;
        int bpm = 120;
        SoundPlayer ding = new SoundPlayer(@"..\..\assets\audio\ding.wav");
        SoundPlayer dong = new SoundPlayer(@"..\..\assets\audio\dong.wav");
        SoundPlayer doo = new SoundPlayer(@"..\..\assets\audio\doo.wav");
        Button[] lights;
        float tick_per_beats = 1000*60/120;//while bpm = 120
        int beats = 0;
        int cycle = 4;
        Boolean twice = false ;
        public Form1()
        {
            InitializeComponent();
            lights = new Button [8]{ light1, light2,light3,light4,light5,light6,light7,light8};
            Console.WriteLine(tick_per_beats);
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            if(btn_start.Text == "Start")
            {
                btn_start.Text = "Stop";
                timer1.Enabled = true;
            }
            else
            {
                btn_start.Text = "Start";
                timer1.Enabled = false;
            }
            reset();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            bpm = trackBar1.Value;
            label_bpm.Text = string.Format("{0}BPM", bpm);
            tick_per_beats = 1000 * 60 / bpm;
            if (twice) { tick_per_beats = 1000 * 60/2 / bpm; }
            Console.WriteLine(tick_per_beats);
            reset();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time+=105;//因為tick update 會有誤差 所以給她1.05倍時間的補償
            if (time % 500 == 0)
            {
                Console.WriteLine(time);
            }
            //Console.WriteLine(time / tick_per_beats);
            if (beats < time / tick_per_beats)
            {
                //    Console.WriteLine(time);
                if(beats%cycle == 0)
                {
                    ding.Play();
                    lights[0].BackColor = Color.LightGreen;
                    if (Convert.ToInt32(emphasis.Text) == 8) {lights[7].BackColor = Color.Gainsboro;}
                    else { lights[6].BackColor = Color.Gainsboro; }
                }
                else
                {
                    if(twice && beats%2 == 1)
                    {
                        dong.Play();
                    }
                    else
                    {
                        if (Convert.ToInt32(emphasis.Text) == 8)
                        {
                            Console.WriteLine(tick_per_beats);
                            if (twice)
                            {
                                lights[beats/2 % 8-1] . BackColor = Color.Gainsboro;
                                lights[beats/2 % 8] . BackColor = Color.LightGreen;
                            }
                            else
                            {
                                lights[beats% 8 - 1].BackColor = Color.Gainsboro;
                                lights[beats% 8].BackColor = Color.LightGreen;
                            }
                        }
                        else 
                        {
                            lights[(beats / (Convert.ToInt32(twice) + 1)) % (cycle/(Convert.ToInt32(twice)+1)) * 2 - 2].BackColor = Color.Gainsboro;
                            lights[(beats / (Convert.ToInt32(twice) + 1)) % (cycle / (Convert.ToInt32(twice) + 1)) * 2].BackColor = Color.LightGreen;
                        }
                        doo.Play();
                    }
                }
                beats++;
            }
        }

        private void emphasis_SelectedIndexChanged(object sender, EventArgs e)
        {
            cycle = Convert.ToInt32(emphasis.Text);
            cycle = twice ? cycle * 2 : cycle;
            reset();
            if (emphasis.Text == "8")
            {
                foreach(Button i in lights)
                {
                    i.Visible = true;
                }
            }
            if(emphasis.Text == "4")
            {
                for(int i=1;i<8; i += 2)
                {
                    lights[i].Visible = false;
                }
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            twice = true;
            tick_per_beats = 1000 * 60 / (bpm*2);
            cycle = cycle * 2;
            reset();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            twice = false;
            tick_per_beats = 1000 * 60 / bpm;
            cycle = Convert.ToInt32(emphasis.Text);
            reset();

        }
        private void reset()
        {
            time = 0;
            beats = 0;
            foreach (Button i in lights) { i.BackColor = Color.Gainsboro; }
        }
    }
}
