﻿namespace Metronome
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label_bpm = new System.Windows.Forms.Label();
            this.btn_start = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.light1 = new System.Windows.Forms.Button();
            this.light2 = new System.Windows.Forms.Button();
            this.light3 = new System.Windows.Forms.Button();
            this.light7 = new System.Windows.Forms.Button();
            this.light4 = new System.Windows.Forms.Button();
            this.light6 = new System.Windows.Forms.Button();
            this.light5 = new System.Windows.Forms.Button();
            this.light8 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.emphasis = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label_bpm
            // 
            this.label_bpm.AutoSize = true;
            this.label_bpm.Font = new System.Drawing.Font("新細明體", 24F);
            this.label_bpm.Location = new System.Drawing.Point(352, 48);
            this.label_bpm.Name = "label_bpm";
            this.label_bpm.Size = new System.Drawing.Size(124, 32);
            this.label_bpm.TabIndex = 0;
            this.label_bpm.Text = "120BPM";
            // 
            // btn_start
            // 
            this.btn_start.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_start.Location = new System.Drawing.Point(375, 428);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(83, 31);
            this.btn_start.TabIndex = 2;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(202, 112);
            this.trackBar1.Maximum = 180;
            this.trackBar1.Minimum = 60;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(428, 45);
            this.trackBar1.TabIndex = 1;
            this.trackBar1.Value = 120;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // light1
            // 
            this.light1.BackColor = System.Drawing.Color.Gainsboro;
            this.light1.Enabled = false;
            this.light1.Location = new System.Drawing.Point(183, 172);
            this.light1.Name = "light1";
            this.light1.Size = new System.Drawing.Size(30, 30);
            this.light1.TabIndex = 2;
            this.light1.UseVisualStyleBackColor = false;
            // 
            // light2
            // 
            this.light2.BackColor = System.Drawing.Color.Gainsboro;
            this.light2.Enabled = false;
            this.light2.Location = new System.Drawing.Point(251, 172);
            this.light2.Name = "light2";
            this.light2.Size = new System.Drawing.Size(30, 30);
            this.light2.TabIndex = 2;
            this.light2.UseVisualStyleBackColor = false;
            this.light2.Visible = false;
            // 
            // light3
            // 
            this.light3.BackColor = System.Drawing.Color.Gainsboro;
            this.light3.Enabled = false;
            this.light3.Location = new System.Drawing.Point(314, 172);
            this.light3.Name = "light3";
            this.light3.Size = new System.Drawing.Size(30, 30);
            this.light3.TabIndex = 2;
            this.light3.UseVisualStyleBackColor = false;
            // 
            // light7
            // 
            this.light7.BackColor = System.Drawing.Color.Gainsboro;
            this.light7.Enabled = false;
            this.light7.Location = new System.Drawing.Point(569, 172);
            this.light7.Name = "light7";
            this.light7.Size = new System.Drawing.Size(30, 30);
            this.light7.TabIndex = 2;
            this.light7.UseVisualStyleBackColor = false;
            // 
            // light4
            // 
            this.light4.BackColor = System.Drawing.Color.Gainsboro;
            this.light4.Enabled = false;
            this.light4.Location = new System.Drawing.Point(384, 172);
            this.light4.Name = "light4";
            this.light4.Size = new System.Drawing.Size(30, 30);
            this.light4.TabIndex = 2;
            this.light4.UseVisualStyleBackColor = false;
            this.light4.Visible = false;
            // 
            // light6
            // 
            this.light6.BackColor = System.Drawing.Color.Gainsboro;
            this.light6.Enabled = false;
            this.light6.Location = new System.Drawing.Point(508, 172);
            this.light6.Name = "light6";
            this.light6.Size = new System.Drawing.Size(30, 30);
            this.light6.TabIndex = 2;
            this.light6.UseVisualStyleBackColor = false;
            this.light6.Visible = false;
            // 
            // light5
            // 
            this.light5.BackColor = System.Drawing.Color.Gainsboro;
            this.light5.Enabled = false;
            this.light5.Location = new System.Drawing.Point(446, 172);
            this.light5.Name = "light5";
            this.light5.Size = new System.Drawing.Size(30, 30);
            this.light5.TabIndex = 2;
            this.light5.UseVisualStyleBackColor = false;
            // 
            // light8
            // 
            this.light8.BackColor = System.Drawing.Color.Gainsboro;
            this.light8.Enabled = false;
            this.light8.Location = new System.Drawing.Point(638, 172);
            this.light8.Name = "light8";
            this.light8.Size = new System.Drawing.Size(30, 30);
            this.light8.TabIndex = 2;
            this.light8.UseVisualStyleBackColor = false;
            this.light8.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F);
            this.label4.Location = new System.Drawing.Point(172, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "60";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F);
            this.label5.Location = new System.Drawing.Point(636, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "180";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(277, 356);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 6;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.radioButton2.Location = new System.Drawing.Point(508, 355);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 6;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(213, 229);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(145, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(446, 229);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 120);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F);
            this.label1.Location = new System.Drawing.Point(287, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Beat Emphasis";
            // 
            // emphasis
            // 
            this.emphasis.FormattingEnabled = true;
            this.emphasis.Items.AddRange(new object[] {
            "4",
            "8"});
            this.emphasis.Location = new System.Drawing.Point(446, 394);
            this.emphasis.Name = "emphasis";
            this.emphasis.Size = new System.Drawing.Size(121, 20);
            this.emphasis.TabIndex = 9;
            this.emphasis.Text = "4";
            this.emphasis.SelectedIndexChanged += new System.EventHandler(this.emphasis_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 481);
            this.Controls.Add(this.emphasis);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.light8);
            this.Controls.Add(this.light5);
            this.Controls.Add(this.light6);
            this.Controls.Add(this.light4);
            this.Controls.Add(this.light7);
            this.Controls.Add(this.light3);
            this.Controls.Add(this.light2);
            this.Controls.Add(this.light1);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.label_bpm);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_bpm;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Button light1;
        private System.Windows.Forms.Button light2;
        private System.Windows.Forms.Button light3;
        private System.Windows.Forms.Button light7;
        private System.Windows.Forms.Button light4;
        private System.Windows.Forms.Button light6;
        private System.Windows.Forms.Button light5;
        private System.Windows.Forms.Button light8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox emphasis;
    }
}

