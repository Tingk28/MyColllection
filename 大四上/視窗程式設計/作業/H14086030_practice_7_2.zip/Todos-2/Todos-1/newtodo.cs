﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Todos_1
{
    public partial class newtodo : Form
    {
        public newtodo()
        {
            InitializeComponent();
            this.Text = "待辦事項";
        }

        private void yes_Click(object sender, EventArgs e)
        {
            if(input.Text == "")
            {
                MessageBox.Show("請輸入事項");
            }
            else { this.Close(); }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            input.Text = "";
            this.Close();
        }
        public String get_todo() { return input.Text; }
    }
}
