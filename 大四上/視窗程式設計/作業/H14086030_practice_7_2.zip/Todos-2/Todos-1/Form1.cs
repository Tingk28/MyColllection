﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Todos_1
{
    public partial class Form1 : Form
    {
        private List<String> todolist = new List<string>();
        private bool hide_finish = false;//預設不隱藏已完成事項
        String path = "";
        public Form1()
        {
            InitializeComponent();
            this.Text = "未命名* - 待辦清單";
        }

        private void 離開ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            if(btn_new.Text == "新增事項")
            {
                newtodo f2 = new newtodo();
                this.Enabled = false;
                f2.ShowDialog();
                if(f2.get_todo() != "")
                {
                    todolist.Add("-" + f2.get_todo());
                    todos.Text = List2Todo(todolist, hide_finish);
                }
                this.Enabled = true;
            }
            else//執行搜尋功能顯示關閉按鈕
            {
                todos.Text = List2Todo(todolist, hide_finish);
                menuStrip1.Enabled = true;
                btn_finsish.Visible = true;
                btn_new.Text = "新增事項";

            }
        }
        private void btn_finsish_Click(object sender, EventArgs e)
        {
            newtodo f2 = new newtodo();
            this.Enabled = false;
            f2.ShowDialog();
            if (f2.get_todo() != "")
            {
                for(int i =0;i<todolist.Count;i++)
                {
                    string temp = todolist[i];
                    if (temp.Substring(1) == f2.get_todo())//如果一模一樣
                    {
                        temp = '+' + temp.Substring(1);
                        todolist[i] = temp;
                    }
                }
                todos.Text = List2Todo(todolist, hide_finish);
            }
            this.Enabled = true;
        }
        private void 開啟ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Todo Files (*.todo)|*.todo|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if(open.ShowDialog() == DialogResult.OK)
            {
                path = open.FileName;
                StreamReader sr = new StreamReader(path);
                while (!sr.EndOfStream)
                {
                    todolist.Add(sr.ReadLine());
                }
                sr.Close();
                todos.Text = List2Todo(todolist, hide_finish);
                this.Text = path.Split('\\')[path.Split('\\').Length - 1] + " - 待辦清單";
            }
        }
        private void 另存新檔ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Todo Files (*.todo)|*.todo|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            save.DefaultExt = "todo";
            //save.AddExtension = true;

            if(save.ShowDialog() == DialogResult.OK)
            {
                path = save.FileName;
                save_file();
                this.Text = path.Split('\\')[path.Split('\\').Length - 1] + "- 待辦清單";
            }
        }

        private void 新增ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            todolist.Clear();
            顯示完成事項ToolStripMenuItem_Click(null, EventArgs.Empty);
            todos.Text = List2Todo(todolist,hide_finish);
            this.Text = "未命名* - 待辦清單";
            path = "";
        }

        private void 儲存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (path == "")
            {
                另存新檔ToolStripMenuItem_Click(null, EventArgs.Empty);
            }
            else { save_file(); }
        }
        public void save_file()
        {
            Console.WriteLine(path);
            FileInfo savefile = new FileInfo(path);
            StreamWriter sw = savefile.CreateText();
            sw.Write(String.Join("\r\n", todolist));
            sw.Flush();
            sw.Close();
        }

        private void 字型大小ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog1 = new FontDialog();

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                todos.Font = fontDialog1.Font;
            }

        }
        private String List2Todo(List<string> input,bool hide)
        {
            List<string> temp = new List<string>();
            //是否隱藏已完成事項
            if (hide)//隱藏
            {
                foreach (string i in todolist)
                {
                    if (i[0] == '-') { temp.Add(i); }
                }
            }
            else { temp = input; }//不隱藏

            String result = "";
            foreach(String i in temp)
            {
                try
                {
                    result += string.Format("{0}  [{1}]  {2}", result == "" ? "" : "\r\n", i[0] == '+' ? "√" : "    ", i.Substring(1, i.Length - 1));
                    //{0}: 是否為第一個(是否換行) {1}:完成或未完成 {2}:todo內容
                }
                catch(Exception e)
                {
                    MessageBox.Show("開啟的資料格式有誤，請檢查");
                    break;
                }
            }
            return result;
        }

        private void 顯示完成事項ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顯示完成事項ToolStripMenuItem.Checked = true;
            隱藏完成事項ToolStripMenuItem.Checked = false;
            hide_finish = false;
            todos.Text = List2Todo(todolist, hide_finish);
        }

        private void 隱藏完成事項ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顯示完成事項ToolStripMenuItem.Checked = false;
            隱藏完成事項ToolStripMenuItem.Checked = true;
            hide_finish = true;
            todos.Text = List2Todo(todolist, hide_finish);
        }

        private void 刪除事項ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            newtodo f2 = new newtodo();
            this.Enabled = false;
            f2.ShowDialog();
            if (f2.get_todo() != "")
            {
                for (int i = 0; i < todolist.Count; i++)
                {
                    string temp = todolist[i];
                    if (temp.Substring(1) == f2.get_todo())//如果一模一樣
                    {
                        todolist.RemoveAt(i);
                    }
                }
                todos.Text = List2Todo(todolist, hide_finish);//update
            }
            this.Enabled = true;
        }

        private void 尋找ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            newtodo f2 = new newtodo();
            this.Enabled = false;
            f2.ShowDialog();
            if (f2.get_todo() != "")
            {
                List<string> searchresult = new List<string>();
                for (int i = 0; i < todolist.Count; i++)
                {
                    string temp = todolist[i];
                    if (temp.Substring(1).Contains(f2.get_todo()))//如果一模一樣
                    {
                        searchresult.Add(temp);
                    }
                }
                if (searchresult.Count > 0)//有搜到東西
                {
                    todos.Text = List2Todo(searchresult, false);//show search result
                    menuStrip1.Enabled = false;
                    btn_finsish.Visible = false;
                    btn_new.Text = "關閉搜尋";
                }
            }
            this.Enabled = true;
        }
    }
}
