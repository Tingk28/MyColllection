﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardGame1
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    public partial class ID_Button : System.Windows.Forms.Button
    {
        private int id;
        private Boolean open = false;
        public ID_Button(int i)
        {
            id = i;
        }
        public int Get_ID()
        {
            return id;
        }
    }
}
