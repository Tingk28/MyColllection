﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp2
{
    
    public partial class Form1 : Form
    {
        List<Account> acclist = new List<Account>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(btnadddel.Text == "新增或刪除")
            {
                label3.Visible = false;
                pwdlist.Visible = false;
                btnriskacc.Text = "風險密碼";
                btnriskacc.Enabled = false;
                btnsearch.Enabled = false;
                searchbar.Enabled = false;
                searchbar.Text = "";
                btnadddel.Text = "回主畫面";

                statusbar.Visible = true;
                statusbar.Text = "我是狀態列";
                lablink.Visible = true;
                labuser.Visible = true;
                labpwd.Visible = true;

                textboxlink.Visible = true;
                textboxlink.Text = "";
                textboxuser.Visible = true;
                textboxuser.Text = "";
                textboxpwd.Visible = true;
                textboxpwd.Text = "";
                btnadd.Visible = true;
                btndel.Visible = true;




            }
            else
            {
                label3.Visible = true;
                pwdlist.Visible = true;
                btnriskacc.Text = "風險帳號";
                btnriskacc.Enabled = true;
                btnsearch.Enabled = true;
                searchbar.Enabled = true;
                searchbar.Text = "";
                btnadddel.Text = "新增或刪除";

                statusbar.Visible = false;
                lablink.Visible = false;
                labuser.Visible = false;
                labpwd.Visible = false;
                textboxlink.Visible = false;
                textboxuser.Visible = false;
                textboxpwd.Visible = false;
                btnadd.Visible = false;
                btndel.Visible = false;

                pwdlist.Text = "";
                /*for(int i=0; i<acclist.Count; i++)
                {
                    String[] temp = acclist[i].ToStringArr();
                    pwdlist.Text += String.Format("連結: {0} \r\n使用者: {1} \r\n密碼: {2}\r\n==========================\r\n", temp[0], temp[1], temp[2]);
                }*/
                
            }

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Boolean exist = false;
            for (int i = 0; i < acclist.Count; i++)
            {
                Account olddata = acclist[i];
                if(textboxlink.Text==olddata.ToStringArr()[0] && textboxuser.Text == olddata.ToStringArr()[1])
                {
                    statusbar.Text = "帳號已存在";
                    exist = true;
                    break;
                }
            }
            if (!exist)
            {
                Account temp = new Account(textboxlink.Text, textboxuser.Text, textboxpwd.Text);
                acclist.Add(temp);
                textboxlink.Text = "";
                textboxuser.Text = "";
                textboxpwd.Text = "";
                statusbar.Text = "新增完成";
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            Boolean exist = false;
            for (int i = 0; i < acclist.Count; i++)
            {
                Account olddata = acclist[i];
                if (textboxlink.Text == olddata.ToStringArr()[0] && textboxuser.Text == olddata.ToStringArr()[1] && textboxpwd.Text == olddata.ToStringArr()[2])
                {
                    acclist.RemoveAt(i);
                    textboxlink.Text = "";
                    textboxuser.Text = "";
                    textboxpwd.Text = "";
                    statusbar.Text = "刪除完成";
                    exist = true;
                    break;
                }
            }
            if (!exist)
            {
                statusbar.Text = "帳號不存在或密碼錯誤";
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            List<Account> templist = new List<Account>();

            for (int i = 0; i < acclist.Count; i++)
            {
                String temp = acclist[i].ToStringArr()[0];
                if(temp.IndexOf(searchbar.Text) != -1)
                {
                    templist.Add(acclist[i]);
                }
            }

            pwdlist.Text = "";
            for (int i = 0; i < templist.Count; i++)
            {
                String[] temp = templist[i].ToStringArr();
                pwdlist.Text += String.Format("連結: {0} \r\n使用者: {1} \r\n密碼: {2}\r\n==========================\r\n", temp[0], temp[1], temp[2]);
            }
        }

        private void btnriskacc_Click(object sender, EventArgs e)
        {
            List<Account> templist = new List<Account>();
            List<String> pwdlist2 = new List<String>();
            List<String> pwdduplicate = new List<String>();

            for (int i = 0; i < acclist.Count; i++)
            {
                String temp = acclist[i].ToStringArr()[2];
                if (pwdlist2.Contains(temp) == false)
                {
                    pwdlist2.Add(temp);
                }
                else if(pwdduplicate.Contains(temp)==false)
                {
                    pwdduplicate.Add(temp);
                }
            }
            for (int i = 0; i < acclist.Count; i++)
            {
                if (pwdduplicate.Contains(acclist[i].ToStringArr()[2]))
                {
                    templist.Add(acclist[i]);
                }
            }

            pwdlist.Text = "";
            for (int i = 0; i < templist.Count; i++)
            {
                String[] temp = templist[i].ToStringArr();
                pwdlist.Text += String.Format("連結: {0} \r\n使用者: {1} \r\n密碼: {2}\r\n==========================\r\n", temp[0], temp[1], temp[2]);
            }
        }
    }
    }
