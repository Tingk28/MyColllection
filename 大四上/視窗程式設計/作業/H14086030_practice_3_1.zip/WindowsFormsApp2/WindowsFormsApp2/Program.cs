﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

class Account
{
    private string link, user, pass;

    public Account(string _link, string _user, string _pass)
    {
        link = _link;
        user = _user;
        pass = _pass;
    }
    public string[] ToStringArr()
    {
        String[] result = { link, user, pass };
        return result;
    }
}


namespace WindowsFormsApp2
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
