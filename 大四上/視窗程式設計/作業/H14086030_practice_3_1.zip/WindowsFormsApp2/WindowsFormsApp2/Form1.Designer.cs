﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.searchbar = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnriskacc = new System.Windows.Forms.Button();
            this.btnadddel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pwdlist = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.statusbar = new System.Windows.Forms.TextBox();
            this.lablink = new System.Windows.Forms.Label();
            this.labuser = new System.Windows.Forms.Label();
            this.labpwd = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.btndel = new System.Windows.Forms.Button();
            this.textboxlink = new System.Windows.Forms.TextBox();
            this.textboxuser = new System.Windows.Forms.TextBox();
            this.textboxpwd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F);
            this.label1.Location = new System.Drawing.Point(65, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "密碼管理員";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F);
            this.label2.Location = new System.Drawing.Point(67, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "搜尋列";
            // 
            // searchbar
            // 
            this.searchbar.Font = new System.Drawing.Font("新細明體", 12F);
            this.searchbar.Location = new System.Drawing.Point(129, 68);
            this.searchbar.Name = "searchbar";
            this.searchbar.Size = new System.Drawing.Size(523, 27);
            this.searchbar.TabIndex = 2;
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnsearch.Location = new System.Drawing.Point(670, 69);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 26);
            this.btnsearch.TabIndex = 3;
            this.btnsearch.Text = "搜尋";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnriskacc
            // 
            this.btnriskacc.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnriskacc.Location = new System.Drawing.Point(67, 118);
            this.btnriskacc.Name = "btnriskacc";
            this.btnriskacc.Size = new System.Drawing.Size(678, 30);
            this.btnriskacc.TabIndex = 4;
            this.btnriskacc.Text = "風險帳號";
            this.btnriskacc.UseVisualStyleBackColor = true;
            this.btnriskacc.Click += new System.EventHandler(this.btnriskacc_Click);
            // 
            // btnadddel
            // 
            this.btnadddel.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnadddel.Location = new System.Drawing.Point(585, 172);
            this.btnadddel.Name = "btnadddel";
            this.btnadddel.Size = new System.Drawing.Size(160, 23);
            this.btnadddel.TabIndex = 5;
            this.btnadddel.Text = "新增或刪除";
            this.btnadddel.UseVisualStyleBackColor = true;
            this.btnadddel.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F);
            this.label3.Location = new System.Drawing.Point(67, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "搜尋結果";
            // 
            // pwdlist
            // 
            this.pwdlist.Font = new System.Drawing.Font("新細明體", 12F);
            this.pwdlist.Location = new System.Drawing.Point(68, 201);
            this.pwdlist.Multiline = true;
            this.pwdlist.Name = "pwdlist";
            this.pwdlist.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.pwdlist.Size = new System.Drawing.Size(676, 215);
            this.pwdlist.TabIndex = 7;
            // 
            // statusbar
            // 
            this.statusbar.Font = new System.Drawing.Font("新細明體", 12F);
            this.statusbar.Location = new System.Drawing.Point(192, 219);
            this.statusbar.Name = "statusbar";
            this.statusbar.ReadOnly = true;
            this.statusbar.Size = new System.Drawing.Size(416, 27);
            this.statusbar.TabIndex = 2;
            this.statusbar.Text = "我是狀態列";
            this.statusbar.Visible = false;
            // 
            // lablink
            // 
            this.lablink.AutoSize = true;
            this.lablink.Font = new System.Drawing.Font("新細明體", 12F);
            this.lablink.Location = new System.Drawing.Point(189, 267);
            this.lablink.Name = "lablink";
            this.lablink.Size = new System.Drawing.Size(40, 16);
            this.lablink.TabIndex = 6;
            this.lablink.Text = "連結";
            this.lablink.Visible = false;
            // 
            // labuser
            // 
            this.labuser.AutoSize = true;
            this.labuser.Font = new System.Drawing.Font("新細明體", 12F);
            this.labuser.Location = new System.Drawing.Point(189, 314);
            this.labuser.Name = "labuser";
            this.labuser.Size = new System.Drawing.Size(56, 16);
            this.labuser.TabIndex = 6;
            this.labuser.Text = "使用者";
            this.labuser.Visible = false;
            // 
            // labpwd
            // 
            this.labpwd.AutoSize = true;
            this.labpwd.Font = new System.Drawing.Font("新細明體", 12F);
            this.labpwd.Location = new System.Drawing.Point(189, 362);
            this.labpwd.Name = "labpwd";
            this.labpwd.Size = new System.Drawing.Size(40, 16);
            this.labpwd.TabIndex = 6;
            this.labpwd.Text = "密碼";
            this.labpwd.Visible = false;
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnadd.Location = new System.Drawing.Point(469, 390);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(60, 26);
            this.btnadd.TabIndex = 3;
            this.btnadd.Text = "新增";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Visible = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btndel
            // 
            this.btndel.Font = new System.Drawing.Font("新細明體", 12F);
            this.btndel.Location = new System.Drawing.Point(548, 390);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(60, 26);
            this.btndel.TabIndex = 3;
            this.btndel.Text = "刪除";
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Visible = false;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // textboxlink
            // 
            this.textboxlink.Font = new System.Drawing.Font("新細明體", 12F);
            this.textboxlink.Location = new System.Drawing.Point(267, 264);
            this.textboxlink.Name = "textboxlink";
            this.textboxlink.Size = new System.Drawing.Size(341, 27);
            this.textboxlink.TabIndex = 2;
            this.textboxlink.Visible = false;
            // 
            // textboxuser
            // 
            this.textboxuser.Font = new System.Drawing.Font("新細明體", 12F);
            this.textboxuser.Location = new System.Drawing.Point(267, 310);
            this.textboxuser.Name = "textboxuser";
            this.textboxuser.Size = new System.Drawing.Size(341, 27);
            this.textboxuser.TabIndex = 2;
            this.textboxuser.Visible = false;
            // 
            // textboxpwd
            // 
            this.textboxpwd.Font = new System.Drawing.Font("新細明體", 12F);
            this.textboxpwd.Location = new System.Drawing.Point(267, 357);
            this.textboxpwd.Name = "textboxpwd";
            this.textboxpwd.Size = new System.Drawing.Size(341, 27);
            this.textboxpwd.TabIndex = 2;
            this.textboxpwd.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 441);
            this.Controls.Add(this.labpwd);
            this.Controls.Add(this.labuser);
            this.Controls.Add(this.lablink);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnadddel);
            this.Controls.Add(this.btnriskacc);
            this.Controls.Add(this.btndel);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.textboxpwd);
            this.Controls.Add(this.textboxuser);
            this.Controls.Add(this.textboxlink);
            this.Controls.Add(this.statusbar);
            this.Controls.Add(this.searchbar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pwdlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox searchbar;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnriskacc;
        private System.Windows.Forms.Button btnadddel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox pwdlist;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox statusbar;
        private System.Windows.Forms.Label lablink;
        private System.Windows.Forms.Label labuser;
        private System.Windows.Forms.Label labpwd;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.TextBox textboxlink;
        private System.Windows.Forms.TextBox textboxuser;
        private System.Windows.Forms.TextBox textboxpwd;
    }
}

