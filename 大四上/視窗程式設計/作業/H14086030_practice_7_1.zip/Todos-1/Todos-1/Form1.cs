﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Todos_1
{
    public partial class Form1 : Form
    {
        String path = "";
        public Form1()
        {
            InitializeComponent();
            this.Text = "未命名* - 待辦清單";
        }

        private void 離開ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            newtodo f2 = new newtodo();
            this.Enabled = false;
            f2.ShowDialog();
            if(f2.get_todo() != "")
            {
                if(todos.Text == "")
                {
                    todos.Text += f2.get_todo();
                }
                else
                {
                    todos.Text += "\r\n" + f2.get_todo();
                }
            }
            this.Enabled = true;
        }

        private void 開啟ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Todo Files (*.todo)|*.todo|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if(open.ShowDialog() == DialogResult.OK)
            {
                path = open.FileName;
                StreamReader sr = new StreamReader(path);
                todos.Text = sr.ReadToEnd();
                sr.Close();
                this.Text = path.Split('\\')[path.Split('\\').Length - 1] + " - 待辦清單";
            }
        }
        private void 另存新檔ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Todo Files (*.todo)|*.todo|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            save.DefaultExt = "todo";
            //save.AddExtension = true;

            if(save.ShowDialog() == DialogResult.OK)
            {
                path = save.FileName;
                save_file();
                this.Text = path.Split('\\')[path.Split('\\').Length - 1] + "- 待辦清單";
            }
        }

        private void 新增ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            todos.Text = "";
            this.Text = "未命名* - 待辦清單";
            path = "";
        }

        private void 儲存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (path == "")
            {
                另存新檔ToolStripMenuItem_Click(null, EventArgs.Empty);
            }
            else { save_file(); }
        }
        public void save_file()
        {
            Console.WriteLine(path);
            FileInfo savefile = new FileInfo(path);
            StreamWriter sw = savefile.CreateText();
            sw.Write(todos.Text);
            sw.Flush();
            sw.Close();
        }

        private void 字型大小ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog1 = new FontDialog();

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                todos.Font = fontDialog1.Font;
            }

        }
    }
}
