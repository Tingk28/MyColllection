﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int Income=0, Expense=0, command=0;
            int balance = Income - Expense;
            int ExpenseListLength = 0;
            int [] ExpenseAmountList = new int[5];
            string[] ExpenseNameList = new string[5];

            while (command != 8)
            {
                Console.WriteLine("(1)輸入收入 (2)輸入支出 (3)新增項目 (4)刪除項目 (5)計算比例 (6)查詢支出 (7)剩餘金額 (8)退出程式");
                Console.Write("輸入數字選擇功能：");
                try
                {
                    command = Convert.ToInt32(Console.ReadLine());
                    if (command > 9 || command < 1)
                    {
                        Console.WriteLine("請輸入數字1-8\n");
                        continue;
                    }
                }
                catch
                {
                    Console.WriteLine("請輸入數字指令\n");
                    continue;
                }
                if (command == 1) //輸入收入
                {
                    Console.Write("輸入金額：");
                    try
                    {
                        int temp = Convert.ToInt32(Console.ReadLine());
                        if(temp < 0)
                        {
                            Console.WriteLine("收入不可為負數\n");
                            continue;
                        }
                        Income += temp;
                    }
                    catch
                    {
                        Console.WriteLine("請輸入數字");
                    }
                }
                else if (command == 2)//輸入支出
                {
                    //Console.WriteLine(ExpenseListLength);
                    if (ExpenseListLength == 0)
                    {
                        Console.WriteLine("請新增支出項目\n");
                        continue;
                    }
                    
                    for(int i =0; i <ExpenseListLength; i++)
                    {
                        Console.WriteLine("({0}){1}", i + 1, ExpenseNameList[i]);
                    }
                    Console.Write("輸入數字選擇支出項目：");
                    try
                    {
                        int ExpenseType = Convert.ToInt32(Console.ReadLine());
                        if(ExpenseType>ExpenseListLength || ExpenseType <= 0)
                        {
                            throw new ArgumentOutOfRangeException();
                        }
                        Console.Write("輸入支出金額：");
                        int TempExpense = Convert.ToInt32(Console.ReadLine());
                        if (TempExpense + Expense > Income)
                        {
                            Console.WriteLine("存款不足");
                            continue;
                        }
                        ExpenseAmountList[ExpenseType - 1] += TempExpense;
                        Expense += TempExpense;
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("金額請輸入數字");
                    }
                    catch
                    {
                        Console.WriteLine("此數字不在範圍中");
                    }
                    
                }

                else if (command == 3)//新增項目
                {
                    if(ExpenseListLength == 5)
                    {
                        Console.WriteLine("已無法再新增支出項目\n");
                        continue;
                    }
                    Console.Write("輸入項目名稱： ");
                    String temp = Console.ReadLine();
                    if (temp == "")
                    {
                        Console.WriteLine("科目名稱不得為空");
                        continue;
                    }
                    else if(ExpenseListLength == 0)
                    {
                        ExpenseNameList[0] = temp;
                        ExpenseListLength++;
                    }
                    else if(ExpenseListLength != 0)
                    {
                        for (int i = 0; i < ExpenseListLength; i++)
                        {
                            if (ExpenseNameList[i] == temp)//已經存在
                            {
                                Console.WriteLine("支出項目已存在");
                                break;
                            }
                            else if (i == ExpenseListLength - 1)//都沒有重複
                            {
                                ExpenseNameList[i+1] = temp;
                                ExpenseListLength++;
                                break;
                            }
                        }
                    }
                }

                else if (command == 4)//刪除項目
                {
                    if (ExpenseListLength == 0)//為空
                    {
                        Console.WriteLine("已無法再刪除支出項目\n");
                        continue;
                    }
                    Console.Write("輸入項目名稱： ");
                    String temp = Console.ReadLine();
                    if (temp == "")
                    {
                        Console.WriteLine("欲刪除科目名稱不得為空");
                        continue;
                    }
                    for (int i = 0; i < ExpenseListLength; i++)
                    {
                        if (ExpenseNameList[i] == temp)//已經存在
                        {
                            ExpenseNameList[i] = "";
                            Expense -= ExpenseAmountList[i];
                            Income -= ExpenseAmountList[i];
                            ExpenseAmountList[i] = 0;
                            ExpenseListLength--;
                            for (int j=i; j < ExpenseListLength; j++)
                            {
                                ExpenseNameList[j] = ExpenseNameList[j+1];
                                ExpenseAmountList[j] = ExpenseAmountList[j + 1];
                            }
                            break;
                        }
                        else if (i == ExpenseListLength - 1)//都沒有重複
                        {
                            Console.WriteLine("此項目不存在");
                        }
                    }
                }
                else if (command == 5)//計算比例
                {
                    for (int i = 0; i < ExpenseListLength; i++)
                    {
                        Console.WriteLine("({0}){1}： {2}%", i+1,ExpenseNameList[i], Expense == 0 ? 0 : (double)ExpenseAmountList[i] * 100 / (double)Expense);
                    }
                }
                else if (command == 6)//查詢支出
                {
                    Console.WriteLine("目前總支出：{0}", Expense);
                    balance = Income - Expense;
                    Console.Write("輸入要查詢的項目：");
                    String temp = Console.ReadLine();
                    if (ExpenseListLength == 0)
                    {
                        Console.WriteLine("此項目不存在");
                        continue;
                    }
                    for (int i = 0; i < ExpenseListLength; i++)
                    {
                        if (ExpenseNameList[i] == temp)//已經存在
                        {
                            Console.WriteLine("{0}：{1}",temp,ExpenseAmountList[i]);
                            break;
                        }
                        else if (i == ExpenseListLength - 1)//都沒有重複
                        {
                            Console.WriteLine("此項目不存在");
                        }
                    }
                    
                }
                else if (command == 7)//剩餘金額
                {
                    balance = Income - Expense;
                    Console.WriteLine("剩餘金額為：{0}", balance);

                }
                Console.Write("\n");
            }
            
        }
    }
}
