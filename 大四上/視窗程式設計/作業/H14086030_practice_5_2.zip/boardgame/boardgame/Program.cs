﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace boardgame
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    public class Board_button : Button
    {
        int x, y;
        public Board_button(int pos_y, int pos_x)
        {
            x = pos_x;
            y = pos_y;
        }
        public int getx()
        {
            return x;
        }
        public int gety()
        {
            return y;
        }
    }
    public class Chess
    {
        protected int hp, mp, atk, atk_range, move_range,x,y;
        
        public void be_attacked(int damage) //
        {
            hp = hp - damage < 0 ? 0 : hp - damage;
        }
        public int get_hp()//回傳攻擊力
        {
            return hp;
        }

        public int get_atk()//回傳攻擊力
        {
            return atk;
        }
        public String get_all_info()
        {
            return string.Format(
                "HP: {0}\r\n" +
                "MP: {1}\r\n" +
                "ATK: {2}\r\n" +
                "ATK Range: {3}\r\n" +
                "MOVE Range: {4}", hp, mp, atk, atk_range, move_range);
        }
        public int getx()
        {
            return x;
        }
        public int gety()
        {
            return y;
        }
        public int get_atk_range()
        {
            return atk_range;
        }
        public int get_move_range()
        {
            return move_range;
        }
        public void setpos(int toy, int tox)
        {
            y = toy;
            x = tox;
        }
        public virtual bool Skill()
        {
            return false;
        }
        public virtual void deSkill(bool success)
        {
        }

    }
    public class Warrior : Chess
    {
        public Warrior(int pos_y, int pos_x)
        {
            hp = 100;
            mp = 15;
            atk = 30;
            atk_range = 1;
            move_range = 2;
            x = pos_x;
            y = pos_y;
        }
        public override bool Skill()
        {
            if (mp > 10) {
                mp -= 10;
                return true;
            }
            else {
                MessageBox.Show("魔力不足");
                return false;
            }
        }
        public override void deSkill(bool success)
        {
            Console.WriteLine("移除技能");
            if (success)//成功攻擊到敵人
            {
                hp = hp + 15 > 100 ? 100 : hp +15;
            }
            else//沒有擊殺敵人
            {
                mp += 10;
            }
        }
    }
    public class Wizrad : Chess
    {
        public Wizrad(int pos_y, int pos_x)
        {
            hp = 70;
            mp = 25;
            atk = 20;
            atk_range = 2;
            move_range = 2;
            x = pos_x;
            y = pos_y;
        }
        public override bool Skill()
        {
            if (mp > 10)
            {
                mp -= 10;
                atk = 40;
                return true;
            }
            else
            {
                MessageBox.Show("魔力不足");
                return false;
            }
        }
        public override void deSkill(bool success)
        {
            Console.WriteLine("移除技能");
            if (success)//成功攻擊到敵人
            {
                atk = 20;
            }
            else//沒有擊殺敵人
            {
                mp += 10;
            }
        }
    }
    public class Ranger : Chess
    {
        public Ranger(int pos_y, int pos_x)
        {
            hp = 90;
            mp = 10;
            atk = 30;
            atk_range = 3;
            move_range = 1;
            x = pos_x;
            y = pos_y;
        }
        public override bool Skill()
        {
            if (mp >= 10)
            {
                mp -= 10;
                atk_range = 4;
                return true;
            }
            else
            {
                MessageBox.Show("魔力不足");
                return false;
            }
        }
        public override void deSkill(bool success)
        {
            Console.WriteLine("移除技能");
            if (success)//成功攻擊到敵人
            {
                atk_range = 3;
            }
            else//沒有擊殺敵人
            {
                mp += 10;
            }
        }
    }
}
