﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace boardgame
{
    public partial class Form1 : Form
    {
        Board_button[,] board = new Board_button[7, 6];
        int select = 0; //當前選擇的職業預設為戰士， -1為沒有拿取
        String[] job = new String[] { "戰士", "法師", "遊俠" };
        Color[] Colors = new Color[] { Color.LightBlue, Color.LightPink };

        int time = 10;
        int turn = 0;//player 1's trun;
        bool preparing = true;
        Button[,] job_buttons;
        Button[,] action_buttons;

        Chess[] allchess = new Chess[6];
        int nowjob = 0;
        int action_id = -1;
        Boolean skilled = false;
        public Form1()
        {
            InitializeComponent();
            job_buttons = new Button[,] {
                { btn_p1_warrior, btn_p1_wizard, btn_p1_ranger },
                { btn_p2_warrior, btn_p2_wizard, btn_p2_ranger } };
            action_buttons = new Button[,]{//[2,5]
                {atk1,move1,skill1,standby1, end1},
                {atk2,move2,skill2,standby2,end2}};
        }
        private void btn_gamestart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            label_status.Visible = true;
            label_status.Enabled = true;
            btn_gamestart.Enabled = false;
            btn_gamestart.Visible = false;

            P1.Visible = true;
            P1.Enabled = true;
            P2.Visible = true;
            P2.Enabled = true;

            btn_p1_warrior.Visible = true;
            btn_p1_warrior.Enabled = true;
            btn_p1_wizard.Visible = true;
            btn_p1_wizard.Enabled = true;
            btn_p1_ranger.Visible = true;
            btn_p1_ranger.Enabled = true;

            btn_p2_warrior.Visible = true;
            btn_p2_wizard.Visible = true;
            btn_p2_ranger.Visible = true;

            for (int i = 0; i < 7; i++)//建立棋盤 並將P2區域禁用
            {
                for (int j = 0; j < 6; j++)
                {
                    board[i, j] = new Board_button(i, j);
                    board[i, j].SetBounds(245 + 50 * j, 80 + 50 * i, 50, 50);
                    board[i, j].Click += new System.EventHandler(this.Board_click);
                    board[i, j].Enabled = false;
                    Controls.Add(board[i, j]);
                }
            }
            prepare(turn);

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time--;
            label_status.Text = String.Format("準備階段\r\n{0}", time);
            if (time == 0)
            {
                for (int i = 0; i < 3; i++)//放置三個棋子
                {
                    if (job_buttons[turn, i].Enabled)//如果該棋子可以放置
                    {
                        for (int j = 0; j < 7; j++)//從左上開始放
                        {
                            if (board[j, turn * 5].Text == "")
                            {
                                board[j, turn * 5].Text = job[i];
                                board[j, turn * 5].BackColor = Colors[turn];
                                job_buttons[turn, i].Enabled = false;
                                break;
                            }
                        }
                    }
                }//換人
                if (turn != 1)
                {
                    turn = 1;
                    prepare(turn);
                }
                else { Gamestart(); }//進入戰鬥階段
            }
        }

        private void Board_click(object sender, EventArgs e)
        {
            Board_button btnclick = (Board_button)sender;
            if (preparing)
            {
                if (btnclick.Text == "" && job_buttons[turn, select].Enabled)
                {
                    btnclick.Text = job[select];
                    btnclick.BackColor = Colors[turn];
                    job_buttons[turn, select].Enabled = false;
                    for (int i = 0; i < 3; i++)
                    {
                        select = select == 2 ? 0 : select + 1;
                        if (job_buttons[turn, select].Enabled)
                        {
                            break;
                        }
                    }
                }
                if (Check_all_placed(turn))//全部都已經放好了 換人
                {
                    if (turn != 1)
                    {
                        turn = 1;
                        prepare(turn);
                    }
                    else //進入戰鬥階段
                    {
                        Gamestart();
                    }
                }
            }
            else
            {   
                //被移動or攻擊棋子原本位子
                int current_x = allchess[turn * 3 + nowjob].getx();
                int current_y = allchess[turn * 3 + nowjob].gety();
                //希望移動or攻擊的位子
                int click_x = btnclick.getx();
                int click_y = btnclick.gety();
                int distance = Math.Abs(current_x - click_x) + Math.Abs(current_y - click_y);

                Label[] labels = new Label[] { P1, P2 };
                Label[] info_labels = new Label[] { p1_info, p2_info };

                if (action_id == 0 || action_id == 2)//攻擊 或帶技能攻擊
                {
                    int opponent = turn == 0 ? 1 : 0;
                    int attck_chess = Array.IndexOf(job, board[click_y, click_x].Text);
                    Console.WriteLine(attck_chess);
                    if (board[click_y,click_x].BackColor != Colors[opponent])
                    {
                        if(board[click_y, click_x].BackColor == Colors[turn])
                        {
                            MessageBox.Show("不可以攻擊己方棋子");
                        }
                        else
                        {
                            MessageBox.Show("請選擇有效目標");
                        }
                    }
                    else if(distance <= allchess[turn * 3 + nowjob].get_atk_range() && (current_x - click_x) * (current_y - click_y) == 0)
                    {

                        int damage = allchess[turn * 3 + nowjob].get_atk();
                        allchess[opponent * 3 + attck_chess].be_attacked(damage);
                        //列印被攻擊目標數據
                        if (skilled)//若有技能
                        {
                            Console.WriteLine("帶技能攻擊");
                            allchess[turn * 3 + nowjob].deSkill(true);
                            Show_info(turn, nowjob);
                            skilled = false;
                        }
                        labels[opponent].Text = string.Format("P{0}\r\n{1}", opponent + 1, job[attck_chess]);
                        info_labels[opponent].Text = allchess[opponent * 3 + attck_chess].get_all_info();
                        
                        if (allchess[opponent * 3 + attck_chess].get_hp() == 0)//被攻擊的棋子死掉了
                        {
                            board[click_y, click_x].Text = "";
                            board[click_y, click_x].BackColor = Color.Gainsboro;
                        }
                        
                        Endaction();
                    }
                    else
                    {
                        MessageBox.Show("超出攻擊範圍");
                    }
                }
                else if (action_id == 1)//移動
                {
                    
                    if (board[click_y, click_x].Text != "")
                    {
                        MessageBox.Show("該位置已經有棋子了");
                    }
                    else if (distance == 0)//原地踏步
                    {
                        //do nothing
                    }
                    else if (distance <= allchess[turn * 3 + nowjob].get_move_range()&& (current_x - click_x)* (current_y - click_y)==0)//移動步數符合且為單一方向移動
                    {
                        board[click_y, click_x].Text = job[nowjob];
                        board[click_y, click_x].BackColor = Colors[turn];
                        board[current_y, current_x].Text = "";
                        board[current_y, current_x].BackColor = Color.Gainsboro;
                        allchess[turn * 3 + nowjob].setpos(click_y, click_x);
                        Endaction();
                    }
                    else//超出移動步數
                    {
                        MessageBox.Show("超出移動範圍");
                        // do nothing
                    }
                }
                else if (action_id == 2)//技能
                {

                }
                //else if (action_id == 3)//待機 do nothing
            }

        }

        private void btn_p1_warrior_Click(object sender, EventArgs e)
        {
            select = 0;
        }

        private void btn_p1_wizard_Click(object sender, EventArgs e)
        {
            select = 1;
        }

        private void btn_p1_ranger_Click(object sender, EventArgs e)
        {
            select = 2;
        }
        private void prepare(int player)
        {
            time = 10;
            select = 0;
            int opponent = player == 0 ? 1 : 0;
            for (int i = 0; i < 7; i++)//建立棋盤
            {
                for (int j = player * 3; j < player * 3 + 3; j++)//0-2 ,3-5
                {
                    if (j < 3)//玩家一
                    {
                        board[i, j].Enabled = true;
                        board[i, j + 3].Enabled = false;
                    }
                    else
                    {
                        board[i, j].Enabled = true;
                        board[i, j - 3].Enabled = false;
                    }
                }
            }
            for (int i = 0; i < 3; i++)
            {
                job_buttons[player, i].Enabled = true;
                job_buttons[opponent, i].Enabled = false;
                //job_buttons[opponent, i].Text = "false";
            }
        }
        private bool Check_all_placed(int player)
        {
            for (int i = 0; i < 3; i++)//若有任一個還沒放置，回傳false
            {
                if (job_buttons[player, i].Enabled) { return false; }
            }
            return true;//全部都已經放了
        }
        private void Switch_player()
        {
            label_status.Text = String.Format("P{0} Turn", turn + 1);
            int opponent = turn == 0 ? 1 : 0;
            for (int i = 0; i < 5; i++)
            {
                action_buttons[turn, i].Enabled = false;
                action_buttons[opponent, i].Enabled = true;
            }
            turn = turn == 0 ? 1 : 0;
        }
        private void Gamestart()
        {
            turn = 0;
            timer1.Enabled = false;
            preparing = false;
            for (int i = 0; i < 5; i++)//顯示動作按鈕
            {
                action_buttons[0, i].Visible = true;
                action_buttons[0, i].Enabled = true;
                action_buttons[1, i].Visible = true;
            }
            action_buttons[0, 4].Enabled = false;

            for (int i = 0; i < 3; i++)//隱藏放置按鈕
            {
                job_buttons[0, i].Visible = false;
                job_buttons[0, i].Enabled = false;
                job_buttons[1, i].Visible = false;
                job_buttons[1, i].Enabled = false;
            }
            for (int i = 0; i < 7; i++)//建立棋盤
            {
                for (int j = 0; j < 6; j++)
                {
                    board[i, j].Enabled = true;
                    if (board[i, j].Text != "")
                    {
                        int player = j < 3 ? 0 : 1;//該棋子屬於哪個玩家
                        if (board[i, j].Text == job[0])//戰士
                        {
                            allchess[player * 3] = new Warrior(i, j);
                        }
                        else if (board[i, j].Text == job[1])//戰士
                        {
                            allchess[player * 3 + 1] = new Wizrad(i, j);
                        }
                        else
                        {
                            allchess[player * 3 + 2] = new Ranger(i, j);
                        }
                    }
                }
            }

            label_status.Text = "P1 Turn";
            p1_info.Text = "";
            p1_info.Visible = true;
            p2_info.Text = "";
            p2_info.Visible = true;

            Show_info(turn, nowjob);
        }

        private void End_Click(object sender, EventArgs e)
        {
            nowjob++;
            while (nowjob < 3)//某棋子已經死掉了 則跳過
            {
                if (allchess[turn * 3 + nowjob].get_hp() == 0) { nowjob++; }
                else { break; }
            }
            
            if (nowjob == 3)
            {
                action_buttons[turn, 4].Enabled = false;//停用己方結束按鈕
                turn = turn == 0 ? 1 : 0;
                nowjob = 0;
                while (nowjob < 3)//某棋子已經死掉了 則跳過
                {
                    if (allchess[turn * 3 + nowjob].get_hp() == 0) { nowjob++; }
                    else { break; }
                }
            }
            Show_info(turn, nowjob);
            Startaction();
            
        }
        private void Show_info(int player, int jobindex)
        {
            int opponent = player == 0 ? 1 : 0;
            Label[] labels = new Label[] { P1, P2 };
            Label[] info_labels = new Label[] { p1_info, p2_info };
            labels[player].Text = string.Format("P{0}\r\n{1}", player+1, job[jobindex]);
            labels[opponent].Text = string.Format("P{0}\r\n", opponent+1);
            info_labels[player].Text = allchess[player * 3 + jobindex].get_all_info();
            info_labels[opponent].Text = "";
        }

        private void atk_Click(object sender, EventArgs e)
        {
            action_id = 0;
            if (skilled)//選擇其他動作
            {
                skilled = false;
                allchess[turn * 3 + nowjob].deSkill(false);
                Show_info(turn, nowjob);
            }
        }
        private void move_Click(object sender, EventArgs e)
        {
            action_id = 1;
            if (skilled)//選擇其他動作
            {
                skilled = false;
                allchess[turn * 3 + nowjob].deSkill(false);
                Show_info(turn, nowjob);
            }
        }
        private void skill_Click(object sender, EventArgs e)
        {
            if (!skilled)
            {
                skilled = allchess[turn * 3 + nowjob].Skill();
                if (skilled)
                {
                    action_id = 2;
                }
                Console.WriteLine(skilled);
                Show_info(turn, nowjob);
            }
        }
        private void Endaction()//結束動作
        {
            action_id = -1;
            for (int i = 0; i < 4; i++)
            {
                action_buttons[turn, i].Enabled = false;
            }
            action_buttons[turn, 4].Enabled = true;
        }
        private void Startaction()//開始動作
        {
            action_id = -1;
            for (int i = 0; i < 4; i++)
            {
                action_buttons[turn, i].Enabled = true;
            }
            action_buttons[turn, 4].Enabled = false;
        }

        private void standby_Click(object sender, EventArgs e)
        {
            action_id = 3;
            Endaction();
        }

        
    }
}
