﻿namespace boardgame
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_gamestart = new System.Windows.Forms.Button();
            this.label_status = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.P1 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.btn_p1_warrior = new System.Windows.Forms.Button();
            this.btn_p1_wizard = new System.Windows.Forms.Button();
            this.btn_p1_ranger = new System.Windows.Forms.Button();
            this.btn_p2_warrior = new System.Windows.Forms.Button();
            this.btn_p2_wizard = new System.Windows.Forms.Button();
            this.btn_p2_ranger = new System.Windows.Forms.Button();
            this.atk1 = new System.Windows.Forms.Button();
            this.move1 = new System.Windows.Forms.Button();
            this.skill1 = new System.Windows.Forms.Button();
            this.standby1 = new System.Windows.Forms.Button();
            this.end1 = new System.Windows.Forms.Button();
            this.atk2 = new System.Windows.Forms.Button();
            this.skill2 = new System.Windows.Forms.Button();
            this.move2 = new System.Windows.Forms.Button();
            this.standby2 = new System.Windows.Forms.Button();
            this.end2 = new System.Windows.Forms.Button();
            this.p1_info = new System.Windows.Forms.Label();
            this.p2_info = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_gamestart
            // 
            this.btn_gamestart.Font = new System.Drawing.Font("新細明體", 16F);
            this.btn_gamestart.Location = new System.Drawing.Point(311, 169);
            this.btn_gamestart.Name = "btn_gamestart";
            this.btn_gamestart.Size = new System.Drawing.Size(163, 84);
            this.btn_gamestart.TabIndex = 0;
            this.btn_gamestart.Text = "開始遊戲";
            this.btn_gamestart.UseVisualStyleBackColor = true;
            this.btn_gamestart.Click += new System.EventHandler(this.btn_gamestart_Click);
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.Enabled = false;
            this.label_status.Font = new System.Drawing.Font("新細明體", 16F);
            this.label_status.Location = new System.Drawing.Point(346, 33);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(98, 44);
            this.label_status.TabIndex = 1;
            this.label_status.Text = "準備階段\r\n10";
            this.label_status.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_status.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // P1
            // 
            this.P1.AutoSize = true;
            this.P1.Enabled = false;
            this.P1.Font = new System.Drawing.Font("新細明體", 16F);
            this.P1.Location = new System.Drawing.Point(103, 94);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(31, 22);
            this.P1.TabIndex = 2;
            this.P1.Text = "P1";
            this.P1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.P1.Visible = false;
            // 
            // P2
            // 
            this.P2.AutoSize = true;
            this.P2.Enabled = false;
            this.P2.Font = new System.Drawing.Font("新細明體", 16F);
            this.P2.Location = new System.Drawing.Point(680, 94);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(31, 22);
            this.P2.TabIndex = 2;
            this.P2.Text = "P2";
            this.P2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.P2.Visible = false;
            // 
            // btn_p1_warrior
            // 
            this.btn_p1_warrior.Enabled = false;
            this.btn_p1_warrior.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p1_warrior.Location = new System.Drawing.Point(73, 151);
            this.btn_p1_warrior.Name = "btn_p1_warrior";
            this.btn_p1_warrior.Size = new System.Drawing.Size(91, 27);
            this.btn_p1_warrior.TabIndex = 3;
            this.btn_p1_warrior.Text = "戰士: 1顆";
            this.btn_p1_warrior.UseVisualStyleBackColor = true;
            this.btn_p1_warrior.Visible = false;
            this.btn_p1_warrior.Click += new System.EventHandler(this.btn_p1_warrior_Click);
            // 
            // btn_p1_wizard
            // 
            this.btn_p1_wizard.Enabled = false;
            this.btn_p1_wizard.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p1_wizard.Location = new System.Drawing.Point(73, 200);
            this.btn_p1_wizard.Name = "btn_p1_wizard";
            this.btn_p1_wizard.Size = new System.Drawing.Size(91, 27);
            this.btn_p1_wizard.TabIndex = 3;
            this.btn_p1_wizard.Text = "法師: 1顆";
            this.btn_p1_wizard.UseVisualStyleBackColor = true;
            this.btn_p1_wizard.Visible = false;
            this.btn_p1_wizard.Click += new System.EventHandler(this.btn_p1_wizard_Click);
            // 
            // btn_p1_ranger
            // 
            this.btn_p1_ranger.Enabled = false;
            this.btn_p1_ranger.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p1_ranger.Location = new System.Drawing.Point(73, 252);
            this.btn_p1_ranger.Name = "btn_p1_ranger";
            this.btn_p1_ranger.Size = new System.Drawing.Size(91, 27);
            this.btn_p1_ranger.TabIndex = 3;
            this.btn_p1_ranger.Text = "遊俠: 1顆";
            this.btn_p1_ranger.UseVisualStyleBackColor = true;
            this.btn_p1_ranger.Visible = false;
            this.btn_p1_ranger.Click += new System.EventHandler(this.btn_p1_ranger_Click);
            // 
            // btn_p2_warrior
            // 
            this.btn_p2_warrior.Enabled = false;
            this.btn_p2_warrior.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p2_warrior.Location = new System.Drawing.Point(654, 151);
            this.btn_p2_warrior.Name = "btn_p2_warrior";
            this.btn_p2_warrior.Size = new System.Drawing.Size(91, 27);
            this.btn_p2_warrior.TabIndex = 3;
            this.btn_p2_warrior.Text = "戰士: 1顆";
            this.btn_p2_warrior.UseVisualStyleBackColor = true;
            this.btn_p2_warrior.Visible = false;
            this.btn_p2_warrior.Click += new System.EventHandler(this.btn_p1_warrior_Click);
            // 
            // btn_p2_wizard
            // 
            this.btn_p2_wizard.Enabled = false;
            this.btn_p2_wizard.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p2_wizard.Location = new System.Drawing.Point(654, 200);
            this.btn_p2_wizard.Name = "btn_p2_wizard";
            this.btn_p2_wizard.Size = new System.Drawing.Size(91, 27);
            this.btn_p2_wizard.TabIndex = 3;
            this.btn_p2_wizard.Text = "法師: 1顆";
            this.btn_p2_wizard.UseVisualStyleBackColor = true;
            this.btn_p2_wizard.Visible = false;
            this.btn_p2_wizard.Click += new System.EventHandler(this.btn_p1_wizard_Click);
            // 
            // btn_p2_ranger
            // 
            this.btn_p2_ranger.Enabled = false;
            this.btn_p2_ranger.Font = new System.Drawing.Font("新細明體", 12F);
            this.btn_p2_ranger.Location = new System.Drawing.Point(654, 252);
            this.btn_p2_ranger.Name = "btn_p2_ranger";
            this.btn_p2_ranger.Size = new System.Drawing.Size(91, 27);
            this.btn_p2_ranger.TabIndex = 3;
            this.btn_p2_ranger.Text = "遊俠: 1顆";
            this.btn_p2_ranger.UseVisualStyleBackColor = true;
            this.btn_p2_ranger.Visible = false;
            this.btn_p2_ranger.Click += new System.EventHandler(this.btn_p1_ranger_Click);
            // 
            // atk1
            // 
            this.atk1.Enabled = false;
            this.atk1.Location = new System.Drawing.Point(73, 297);
            this.atk1.Name = "atk1";
            this.atk1.Size = new System.Drawing.Size(61, 30);
            this.atk1.TabIndex = 4;
            this.atk1.Text = "攻擊";
            this.atk1.UseVisualStyleBackColor = true;
            this.atk1.Visible = false;
            this.atk1.Click += new System.EventHandler(this.atk_Click);
            // 
            // move1
            // 
            this.move1.Enabled = false;
            this.move1.Location = new System.Drawing.Point(140, 297);
            this.move1.Name = "move1";
            this.move1.Size = new System.Drawing.Size(61, 30);
            this.move1.TabIndex = 4;
            this.move1.Text = "移動";
            this.move1.UseVisualStyleBackColor = true;
            this.move1.Visible = false;
            this.move1.Click += new System.EventHandler(this.move_Click);
            // 
            // skill1
            // 
            this.skill1.Enabled = false;
            this.skill1.Location = new System.Drawing.Point(73, 333);
            this.skill1.Name = "skill1";
            this.skill1.Size = new System.Drawing.Size(61, 30);
            this.skill1.TabIndex = 4;
            this.skill1.Text = "技能";
            this.skill1.UseVisualStyleBackColor = true;
            this.skill1.Visible = false;
            this.skill1.Click += new System.EventHandler(this.skill_Click);
            // 
            // standby1
            // 
            this.standby1.Enabled = false;
            this.standby1.Location = new System.Drawing.Point(140, 333);
            this.standby1.Name = "standby1";
            this.standby1.Size = new System.Drawing.Size(61, 30);
            this.standby1.TabIndex = 4;
            this.standby1.Text = "待機";
            this.standby1.UseVisualStyleBackColor = true;
            this.standby1.Visible = false;
            this.standby1.Click += new System.EventHandler(this.standby_Click);
            // 
            // end1
            // 
            this.end1.Enabled = false;
            this.end1.Location = new System.Drawing.Point(73, 376);
            this.end1.Name = "end1";
            this.end1.Size = new System.Drawing.Size(128, 29);
            this.end1.TabIndex = 4;
            this.end1.Text = "結束";
            this.end1.UseVisualStyleBackColor = true;
            this.end1.Visible = false;
            this.end1.Click += new System.EventHandler(this.End_Click);
            // 
            // atk2
            // 
            this.atk2.Enabled = false;
            this.atk2.Location = new System.Drawing.Point(617, 297);
            this.atk2.Name = "atk2";
            this.atk2.Size = new System.Drawing.Size(61, 30);
            this.atk2.TabIndex = 4;
            this.atk2.Text = "攻擊";
            this.atk2.UseVisualStyleBackColor = true;
            this.atk2.Visible = false;
            this.atk2.Click += new System.EventHandler(this.atk_Click);
            // 
            // skill2
            // 
            this.skill2.Enabled = false;
            this.skill2.Location = new System.Drawing.Point(617, 333);
            this.skill2.Name = "skill2";
            this.skill2.Size = new System.Drawing.Size(61, 30);
            this.skill2.TabIndex = 4;
            this.skill2.Text = "技能";
            this.skill2.UseVisualStyleBackColor = true;
            this.skill2.Visible = false;
            this.skill2.Click += new System.EventHandler(this.skill_Click);
            // 
            // move2
            // 
            this.move2.Enabled = false;
            this.move2.Location = new System.Drawing.Point(684, 297);
            this.move2.Name = "move2";
            this.move2.Size = new System.Drawing.Size(61, 30);
            this.move2.TabIndex = 4;
            this.move2.Text = "移動";
            this.move2.UseVisualStyleBackColor = true;
            this.move2.Visible = false;
            this.move2.Click += new System.EventHandler(this.move_Click);
            // 
            // standby2
            // 
            this.standby2.Enabled = false;
            this.standby2.Location = new System.Drawing.Point(684, 333);
            this.standby2.Name = "standby2";
            this.standby2.Size = new System.Drawing.Size(61, 30);
            this.standby2.TabIndex = 4;
            this.standby2.Text = "待機";
            this.standby2.UseVisualStyleBackColor = true;
            this.standby2.Visible = false;
            this.standby2.Click += new System.EventHandler(this.standby_Click);
            // 
            // end2
            // 
            this.end2.Enabled = false;
            this.end2.Location = new System.Drawing.Point(617, 376);
            this.end2.Name = "end2";
            this.end2.Size = new System.Drawing.Size(128, 29);
            this.end2.TabIndex = 4;
            this.end2.Text = "結束";
            this.end2.UseVisualStyleBackColor = true;
            this.end2.Visible = false;
            this.end2.Click += new System.EventHandler(this.End_Click);
            // 
            // p1_info
            // 
            this.p1_info.AutoSize = true;
            this.p1_info.Font = new System.Drawing.Font("新細明體", 14F);
            this.p1_info.Location = new System.Drawing.Point(69, 159);
            this.p1_info.Name = "p1_info";
            this.p1_info.Size = new System.Drawing.Size(36, 19);
            this.p1_info.TabIndex = 5;
            this.p1_info.Text = "111";
            this.p1_info.Visible = false;
            // 
            // p2_info
            // 
            this.p2_info.AutoSize = true;
            this.p2_info.Font = new System.Drawing.Font("新細明體", 14F);
            this.p2_info.Location = new System.Drawing.Point(650, 159);
            this.p2_info.Name = "p2_info";
            this.p2_info.Size = new System.Drawing.Size(36, 19);
            this.p2_info.TabIndex = 6;
            this.p2_info.Text = "222";
            this.p2_info.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.p2_info);
            this.Controls.Add(this.p1_info);
            this.Controls.Add(this.end2);
            this.Controls.Add(this.end1);
            this.Controls.Add(this.standby2);
            this.Controls.Add(this.standby1);
            this.Controls.Add(this.move2);
            this.Controls.Add(this.move1);
            this.Controls.Add(this.skill2);
            this.Controls.Add(this.atk2);
            this.Controls.Add(this.skill1);
            this.Controls.Add(this.atk1);
            this.Controls.Add(this.btn_p2_ranger);
            this.Controls.Add(this.btn_p1_ranger);
            this.Controls.Add(this.btn_p2_wizard);
            this.Controls.Add(this.btn_p1_wizard);
            this.Controls.Add(this.btn_p2_warrior);
            this.Controls.Add(this.btn_p1_warrior);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.btn_gamestart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_gamestart;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label P1;
        private System.Windows.Forms.Label P2;
        private System.Windows.Forms.Button btn_p1_warrior;
        private System.Windows.Forms.Button btn_p1_wizard;
        private System.Windows.Forms.Button btn_p1_ranger;
        private System.Windows.Forms.Button btn_p2_warrior;
        private System.Windows.Forms.Button btn_p2_wizard;
        private System.Windows.Forms.Button btn_p2_ranger;
        private System.Windows.Forms.Button atk1;
        private System.Windows.Forms.Button move1;
        private System.Windows.Forms.Button skill1;
        private System.Windows.Forms.Button standby1;
        private System.Windows.Forms.Button end1;
        private System.Windows.Forms.Button atk2;
        private System.Windows.Forms.Button skill2;
        private System.Windows.Forms.Button move2;
        private System.Windows.Forms.Button standby2;
        private System.Windows.Forms.Button end2;
        private System.Windows.Forms.Label p1_info;
        private System.Windows.Forms.Label p2_info;
    }
}

