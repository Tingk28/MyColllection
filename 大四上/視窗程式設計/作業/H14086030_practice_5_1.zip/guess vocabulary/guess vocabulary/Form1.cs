﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace guess_vocabulary
{
    public partial class Form1 : Form
    {
        List<Char> answer = new List<Char>();
        Letter_Btn[] btnarr = new Letter_Btn[26];
        int wrong = 0;
        int time = 0;
        public Form1()
        {
            InitializeComponent();
            //this.KeyPreview = true;
        }

        private void Input_TextChanged(object sender, EventArgs e)
        {
            answer.Clear();
            String text = Input.Text;
            for(int i =0;i< text.Length; i++)
            {
                char temp = text [i];
                Console.WriteLine(temp);
                if (((int)temp >= 65 && (int)temp <= 97) || ((int)temp >= 97 && (int)temp <= 122))//A:65 Z:90 a:97 z:122
                {
                    answer.Add(temp);
                }
            }
            String correctstr = new String(answer.ToArray());
            Input.Text = correctstr;
            Input.Select(Input.Text.Length, 0);
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            if(answer.Count == 0)
            {
                return;
            }
            for(int i = 0; i < answer.Count; i++)
            {
                if (answer[i] >= 97)
                {
                    answer[i] = (char)(answer[i] - 32);
                }
            }
            Console.WriteLine(answer.ToArray());
            for (int i = 0; i < answer.Count; i++)
            {
                label_ans.Text += "＿ ";
            }

            label_ans.Visible = true;
            label_time.Visible = true;
            label_wrong.Visible = true;

            Input.Visible = false;
            Input.ReadOnly = true;
            btn_start.Enabled = false;
            btn_start.Visible = false;
            Title.Visible = false;
            label1.Visible = false;

            time = 0;
            timer1.Enabled = true;
            for(int i =0; i < 13; i++)
            {
                btnarr[i] = new Letter_Btn((char)('A'+i));
                btnarr[i + 13] = new Letter_Btn((char)('A' + i+13));
                btnarr[i].Text = btnarr[i].get_letter().ToString();
                btnarr[i+13].Text = btnarr[i+13].get_letter().ToString();

                btnarr[i].SetBounds(80 + (45 * i), 80, 30, 30);
                btnarr[i+13].SetBounds(80 + (45 * i), 130, 30, 30);

                btnarr[i].Enabled = false;
                btnarr[i + 13].Enabled=false;

                //buttons[i].Click += new System.EventHandler(this.Card_Click);
                Controls.Add(btnarr[i]);
                Controls.Add(btnarr[i+13]);
            }
            Console.WriteLine(answer.ToArray());
        }

        private void controlItem_KeyDown(object sender, KeyEventArgs e)
        {
            Console.WriteLine(answer.Count);
            Console.WriteLine(e.KeyValue);
            if (e.KeyValue >= 65 && e.KeyValue <= 90)
            {
                Char c = (char)e.KeyValue;
                int charindex = e.KeyValue - 65;


                Console.WriteLine(c);
                Console.WriteLine(answer.Contains(c));
                if (answer.Contains(c))//如果有這個字母
                {
                    btnarr[charindex].BackColor = Color.LightGreen;
                    for(int j = 0; j < answer.Count; j++)
                    {
                        if(c == answer[j])
                        {
                            char [] temp = label_ans.Text.ToArray();
                            temp[j * 2] = c;
                            label_ans.Text = new string(temp);
                        }
                    }
                    if (label_ans.Text.IndexOf('＿') == -1)//猜對了
                    {
                        timer1.Enabled = false;
                        MessageBox.Show(string.Format("花費時間:{0}\r\n猜錯 {1} 次",time,wrong));
                        Restart();
                    }
                    //answer.Remove(c);
                }
                else//如果沒有
                {
                    if (btnarr[charindex].Visible)
                    {
                        btnarr[charindex].Visible = false;
                        //wrong++;

                        label_wrong.Text = string.Format("猜錯次數: {0}次", ++wrong);
                        if (wrong == 6)
                        {
                            timer1.Enabled = false;
                            for (int j = 0; j < answer.Count; j++)//show answer
                            {
                                char[] temp = label_ans.Text.ToArray();
                                temp[j * 2] = answer[j];
                                label_ans.Text = new string(temp);
                            }

                            MessageBox.Show("You Lose !");
                            Restart();
                        }
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label_time.Text = string.Format("時間: {0}", time);
            time++;
        }
        private void Restart()
        {
            answer.Clear();
            wrong = 0;
            time = 0;
            label_ans.Visible = false;
            label_ans.Text="";
            label_time.Visible = false;
            label_wrong.Visible = false;
            label_wrong.Text = "猜錯次數: 0次";
            label_time.Text = "時間: 0";

            Input.Visible = true;
            Input.Text = "";
            Input.ReadOnly = false;
            btn_start.Enabled = true;
            btn_start.Visible = true;
            Title.Visible = true;
            label1.Visible = true;
            for(int i = 0; i < 26; i++)
            {
                Controls.Remove(btnarr[i]);
            }
        }
    }
}
