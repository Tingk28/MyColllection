﻿namespace guess_vocabulary
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Title = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Input = new System.Windows.Forms.TextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.label_time = new System.Windows.Forms.Label();
            this.label_wrong = new System.Windows.Forms.Label();
            this.label_ans = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Title.Enabled = false;
            this.Title.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Title.Location = new System.Drawing.Point(217, 67);
            this.Title.Multiline = true;
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            this.Title.Size = new System.Drawing.Size(363, 119);
            this.Title.TabIndex = 0;
            this.Title.Text = "猜英文單字\r\n六次猜錯機會";
            this.Title.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 20F);
            this.label1.Location = new System.Drawing.Point(282, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "請輸入要猜的單字:";
            // 
            // Input
            // 
            this.Input.Font = new System.Drawing.Font("新細明體", 20F);
            this.Input.Location = new System.Drawing.Point(287, 238);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(215, 39);
            this.Input.TabIndex = 2;
            this.Input.TextChanged += new System.EventHandler(this.Input_TextChanged);
            // 
            // btn_start
            // 
            this.btn_start.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn_start.Location = new System.Drawing.Point(287, 307);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(215, 76);
            this.btn_start.TabIndex = 3;
            this.btn_start.Text = "START";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // label_time
            // 
            this.label_time.AutoSize = true;
            this.label_time.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_time.Location = new System.Drawing.Point(736, 78);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(66, 19);
            this.label_time.TabIndex = 4;
            this.label_time.Text = "時間: 0";
            this.label_time.Visible = false;
            // 
            // label_wrong
            // 
            this.label_wrong.AutoSize = true;
            this.label_wrong.Font = new System.Drawing.Font("新細明體", 14F);
            this.label_wrong.Location = new System.Drawing.Point(736, 133);
            this.label_wrong.Name = "label_wrong";
            this.label_wrong.Size = new System.Drawing.Size(123, 19);
            this.label_wrong.TabIndex = 4;
            this.label_wrong.Text = "猜錯次數: 0次";
            this.label_wrong.Visible = false;
            // 
            // label_ans
            // 
            this.label_ans.AutoSize = true;
            this.label_ans.Enabled = false;
            this.label_ans.Font = new System.Drawing.Font("新細明體", 24F);
            this.label_ans.Location = new System.Drawing.Point(296, 328);
            this.label_ans.Name = "label_ans";
            this.label_ans.Size = new System.Drawing.Size(0, 32);
            this.label_ans.TabIndex = 4;
            this.label_ans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_ans.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 460);
            this.Controls.Add(this.label_ans);
            this.Controls.Add(this.label_wrong);
            this.Controls.Add(this.label_time);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.Input);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Title);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.controlItem_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Title;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Input;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Label label_wrong;
        private System.Windows.Forms.Label label_ans;
        private System.Windows.Forms.Timer timer1;
    }
}

