﻿namespace Telephone
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.mediaplayer2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.mediaplayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.btndel = new System.Windows.Forms.Button();
            this.btnhash = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btndial = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btnx = new System.Windows.Forms.Button();
            this.btnstar = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.number = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnsave = new System.Windows.Forms.Button();
            this.history = new System.Windows.Forms.TextBox();
            this.input = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.CausesValidation = false;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabStop = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.mediaplayer2);
            this.tabPage1.Controls.Add(this.mediaplayer1);
            this.tabPage1.Controls.Add(this.btndel);
            this.tabPage1.Controls.Add(this.btnhash);
            this.tabPage1.Controls.Add(this.btn9);
            this.tabPage1.Controls.Add(this.btn6);
            this.tabPage1.Controls.Add(this.btn3);
            this.tabPage1.Controls.Add(this.btndial);
            this.tabPage1.Controls.Add(this.btn0);
            this.tabPage1.Controls.Add(this.btn8);
            this.tabPage1.Controls.Add(this.btn5);
            this.tabPage1.Controls.Add(this.btn2);
            this.tabPage1.Controls.Add(this.btnx);
            this.tabPage1.Controls.Add(this.btnstar);
            this.tabPage1.Controls.Add(this.btn7);
            this.tabPage1.Controls.Add(this.btn4);
            this.tabPage1.Controls.Add(this.btn1);
            this.tabPage1.Controls.Add(this.number);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Telephone";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // mediaplayer2
            // 
            this.mediaplayer2.Enabled = true;
            this.mediaplayer2.Location = new System.Drawing.Point(95, 296);
            this.mediaplayer2.Name = "mediaplayer2";
            this.mediaplayer2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("mediaplayer2.OcxState")));
            this.mediaplayer2.Size = new System.Drawing.Size(59, 78);
            this.mediaplayer2.TabIndex = 2;
            this.mediaplayer2.TabStop = false;
            this.mediaplayer2.Visible = false;
            // 
            // mediaplayer1
            // 
            this.mediaplayer1.Enabled = true;
            this.mediaplayer1.Location = new System.Drawing.Point(42, 296);
            this.mediaplayer1.Name = "mediaplayer1";
            this.mediaplayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("mediaplayer1.OcxState")));
            this.mediaplayer1.Size = new System.Drawing.Size(58, 78);
            this.mediaplayer1.TabIndex = 2;
            this.mediaplayer1.TabStop = false;
            this.mediaplayer1.Visible = false;
            // 
            // btndel
            // 
            this.btndel.BackColor = System.Drawing.Color.Transparent;
            this.btndel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndel.Font = new System.Drawing.Font("新細明體", 18F);
            this.btndel.Location = new System.Drawing.Point(425, 308);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(50, 50);
            this.btndel.TabIndex = 1;
            this.btndel.TabStop = false;
            this.btndel.UseVisualStyleBackColor = false;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // btnhash
            // 
            this.btnhash.Font = new System.Drawing.Font("新細明體", 20F);
            this.btnhash.Location = new System.Drawing.Point(425, 252);
            this.btnhash.Name = "btnhash";
            this.btnhash.Size = new System.Drawing.Size(50, 50);
            this.btnhash.TabIndex = 1;
            this.btnhash.TabStop = false;
            this.btnhash.Text = "#";
            this.btnhash.UseVisualStyleBackColor = true;
            this.btnhash.Click += new System.EventHandler(this.btn_Click);
            this.btnhash.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btnhash.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn9.Location = new System.Drawing.Point(425, 196);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(50, 50);
            this.btn9.TabIndex = 1;
            this.btn9.TabStop = false;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn_Click);
            this.btn9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn6.Location = new System.Drawing.Point(425, 140);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(50, 50);
            this.btn6.TabIndex = 1;
            this.btn6.TabStop = false;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn_Click);
            this.btn6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn3.Location = new System.Drawing.Point(425, 84);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(50, 50);
            this.btn3.TabIndex = 1;
            this.btn3.TabStop = false;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn_Click);
            this.btn3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btndial
            // 
            this.btndial.BackColor = System.Drawing.Color.White;
            this.btndial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndial.Font = new System.Drawing.Font("新細明體", 20F);
            this.btndial.Location = new System.Drawing.Point(330, 308);
            this.btndial.Name = "btndial";
            this.btndial.Size = new System.Drawing.Size(50, 50);
            this.btndial.TabIndex = 1;
            this.btndial.TabStop = false;
            this.btndial.Text = " ";
            this.btndial.UseVisualStyleBackColor = false;
            this.btndial.Click += new System.EventHandler(this.btndial_Click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn0.Location = new System.Drawing.Point(330, 252);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(50, 50);
            this.btn0.TabIndex = 1;
            this.btn0.TabStop = false;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn_Click);
            this.btn0.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn0.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn8.Location = new System.Drawing.Point(330, 196);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(50, 50);
            this.btn8.TabIndex = 1;
            this.btn8.TabStop = false;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn_Click);
            this.btn8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn5.Location = new System.Drawing.Point(330, 140);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(50, 50);
            this.btn5.TabIndex = 1;
            this.btn5.TabStop = false;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn_Click);
            this.btn5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn2.Location = new System.Drawing.Point(330, 84);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(50, 50);
            this.btn2.TabIndex = 1;
            this.btn2.TabStop = false;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn_Click);
            this.btn2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btnx
            // 
            this.btnx.Font = new System.Drawing.Font("新細明體", 20F);
            this.btnx.Location = new System.Drawing.Point(234, 308);
            this.btnx.Name = "btnx";
            this.btnx.Size = new System.Drawing.Size(50, 50);
            this.btnx.TabIndex = 1;
            this.btnx.TabStop = false;
            this.btnx.Text = "X";
            this.btnx.UseVisualStyleBackColor = true;
            this.btnx.Click += new System.EventHandler(this.btnx_Click);
            // 
            // btnstar
            // 
            this.btnstar.Font = new System.Drawing.Font("新細明體", 20F);
            this.btnstar.Location = new System.Drawing.Point(234, 252);
            this.btnstar.Name = "btnstar";
            this.btnstar.Size = new System.Drawing.Size(50, 50);
            this.btnstar.TabIndex = 1;
            this.btnstar.TabStop = false;
            this.btnstar.Text = "*";
            this.btnstar.UseVisualStyleBackColor = true;
            this.btnstar.Click += new System.EventHandler(this.btn_Click);
            this.btnstar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btnstar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn7.Location = new System.Drawing.Point(234, 196);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(50, 50);
            this.btn7.TabIndex = 1;
            this.btn7.TabStop = false;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn_Click);
            this.btn7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn4.Location = new System.Drawing.Point(234, 140);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(50, 50);
            this.btn4.TabIndex = 1;
            this.btn4.TabStop = false;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn_Click);
            this.btn4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("新細明體", 20F);
            this.btn1.Location = new System.Drawing.Point(233, 84);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(50, 50);
            this.btn1.TabIndex = 1;
            this.btn1.TabStop = false;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn_Click);
            this.btn1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseDown);
            this.btn1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.controlItem_MouseUp);
            // 
            // number
            // 
            this.number.AutoSize = true;
            this.number.Font = new System.Drawing.Font("新細明體", 24F);
            this.number.Location = new System.Drawing.Point(36, 24);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(140, 32);
            this.number.TabIndex = 0;
            this.number.Text = "Telephone";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnsave);
            this.tabPage2.Controls.Add(this.history);
            this.tabPage2.Controls.Add(this.input);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Log";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(631, 44);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 2;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // history
            // 
            this.history.Font = new System.Drawing.Font("新細明體", 12F);
            this.history.Location = new System.Drawing.Point(66, 85);
            this.history.Multiline = true;
            this.history.Name = "history";
            this.history.ReadOnly = true;
            this.history.Size = new System.Drawing.Size(640, 290);
            this.history.TabIndex = 1;
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(108, 44);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(502, 22);
            this.input.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F);
            this.label2.Location = new System.Drawing.Point(63, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Save";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.controlItem_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.controlItem_KeyUp);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediaplayer1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.Button btnhash;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btndial;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btnx;
        private System.Windows.Forms.Button btnstar;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Label number;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox history;
        private System.Windows.Forms.TextBox input;
        private AxWMPLib.AxWindowsMediaPlayer mediaplayer2;
        private AxWMPLib.AxWindowsMediaPlayer mediaplayer1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

