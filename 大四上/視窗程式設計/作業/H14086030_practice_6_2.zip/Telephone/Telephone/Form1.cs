﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Telephone
{
    public partial class Form1 : Form
    {
        private String assetpath;
        private int[] horhz = new int[] { 1209, 1336, 1477 };
        private int[] verhz = new int[] { 697, 770, 852, 941 };
        private Image[] Imgs = new Image[4];

        private Button [] btnarr;
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            String[] path = System.Environment.CurrentDirectory.Split('\\');
            string[] newpath = new string[path.Length - 2];
            Array.Copy(path, newpath, path.Length - 2);
            assetpath = String.Join("\\", newpath) + @"\assets\audio\";
            btnarr = new Button[] { btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnstar, btnhash };
            Imgs[0] = Image.FromFile(@"..\..\assets\img\open.jpg");
            Imgs[1] = Image.FromFile(@"..\..\assets\img\close.png");
            Imgs[2] = Image.FromFile(@"..\..\assets\img\del.png");
            Imgs[3] = Image.FromFile(@"..\..\assets\img\deldisable.png");
            btndel.BackgroundImage = Imgs[2];
            btndial.BackgroundImage = Imgs[0];
        }
        private void controlItem_KeyDown(object sender, KeyEventArgs e)
        {
            int down = e.KeyValue;
            int btn;
            int hz1, hz2;
            Console.WriteLine(tabControl1.SelectedIndex);
            if (mediaplayer1.playState != WMPLib.WMPPlayState.wmppsPlaying && tabControl1.SelectedIndex==0)
            {
                if ((down >= 48 && down <= 57) || (down >= 96 && down <= 105))//鍵盤區0-9
                {
                    btn = down % 48;
                    if (e.Shift && btn == 8)//*
                    {
                        btn_Click(btnarr[10], EventArgs.Empty);
                        hz1 = 1209; hz2 = 941;
                    }
                    else if (e.Shift && btn == 3)//#
                    {
                        btn_Click(btnarr[11], EventArgs.Empty);
                        hz1 = 1477; hz2 = 941;
                    }
                    else
                    {
                        btn_Click(btnarr[btn], EventArgs.Empty);
                        hz1 = btn % 3 - 1;
                        hz1 = hz1 < 0 ? 2 : hz1;
                        hz2 = (btn - 1) / 3;
                        hz1 = horhz[hz1];
                        hz2 = verhz[hz2];
                    }
                    mediaplayer1.URL = String.Format("{0}{1}.wav", assetpath, hz1);
                    mediaplayer2.URL = String.Format("{0}{1}.wav", assetpath, hz2);
                    mediaplayer1.Ctlcontrols.play();
                    mediaplayer2.Ctlcontrols.play();
                }
                else if (down == 13)//enter
                {
                    btndial_Click(null, EventArgs.Empty);
                }
                else if (down == 8)//del
                {
                    btndel_Click(null, EventArgs.Empty);
                }
            }
        }

        private void controlItem_KeyUp(object sender, KeyEventArgs e)
        {
            //Console.WriteLine("key up");
            mediaplayer1.Ctlcontrols.pause();
            mediaplayer2.Ctlcontrols.pause();  
        }
        private void btnx_Click(object sender, EventArgs e)
        {
            number.Text = "";
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (number.Text.Length == 1)
            {
                number.Text = "Telephone";
            }
            else if (number.Text == "Telephone" || number.Text =="") { }
            else { number.Text = number.Text.Substring(0, number.Text.Length - 1); }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Button btnclick = (Button)sender;
            if(number.Text == "Telephone")
            {
                number.Text = btnclick.Text;
            }
            else
            {
                number.Text += btnclick.Text;
            }
        }

        private void btndial_Click(object sender, EventArgs e)
        {
            if(number.Text == ""||number.Text == "Telephone")
            {
                MessageBox.Show("請輸入電話號碼");
            }
            else if(btndial.Text==" ")//非通話中
            {
                foreach(Button i in btnarr) { i.Enabled = false; }
                btndel.Enabled = false;
                btnx.Enabled = false;
                btndial.BackgroundImage = Imgs[1];
                btndel.BackgroundImage = Imgs[3];
                btndial.Text = "";
            }
            else//通話中
            {
                foreach (Button i in btnarr) { i.Enabled = true; }
                btndel.Enabled = true;
                btnx.Enabled = true;
                btndial.BackgroundImage = Imgs[0];
                btndel.BackgroundImage = Imgs[2];
                history.Text += number.Text + "\r\n";
                number.Text = "Telephone";
                btndial.Text = " ";
            }
        }



        private void controlItem_MouseDown(object sender, MouseEventArgs e)
        {
            int btn;
            int hz1, hz2;
            Button btnclick = (Button)sender;
            String Btn_mouse = btnclick.Text;


            if (mediaplayer1.playState != WMPLib.WMPPlayState.wmppsPlaying)
            {
                if (Btn_mouse == "#") { hz1 = 1477; hz2 = 941; }
                else if (Btn_mouse == "*") { hz1 = 1209; hz2 = 941; }
                else
                {
                    Console.WriteLine(Btn_mouse == "");
                    Console.WriteLine(Btn_mouse);
                    btn = Convert.ToInt32(Btn_mouse);
                    hz1 = btn % 3 - 1;
                    hz1 = hz1 < 0 ? 2 : hz1;
                    hz2 = (btn - 1) / 3;
                    hz1 = horhz[hz1];
                    hz2 = verhz[hz2];

                }
                mediaplayer1.URL = String.Format("{0}{1}.wav", assetpath, hz1);
                mediaplayer2.URL = String.Format("{0}{1}.wav", assetpath, hz2);
                mediaplayer1.Ctlcontrols.play();
                mediaplayer2.Ctlcontrols.play();
            }
            
        }

        private void controlItem_MouseUp(object sender, MouseEventArgs e)
        {
            //Console.WriteLine("mouse up");
            mediaplayer1.Ctlcontrols.pause();
            mediaplayer2.Ctlcontrols.pause();
            if (mediaplayer1.playState == WMPLib.WMPPlayState.wmppsPlaying || mediaplayer1.playState == WMPLib.WMPPlayState.wmppsTransitioning)
            {
                Console.WriteLine(mediaplayer1.playState);
                mediaplayer1.Ctlcontrols.stop();
                mediaplayer2.Ctlcontrols.stop();
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if(input.Text == "") { MessageBox.Show("Empty String"); }//empty string
            else
            {
                try
                {
                    FileInfo save = new FileInfo(input.Text);
                    StreamWriter sw = save.CreateText();
                    sw.Write(history.Text);
                    sw.Flush();
                    sw.Close();
                    MessageBox.Show(String.Format("Done\r\n{0}",save.FullName));
                }
                catch(System.IO.DirectoryNotFoundException)
                {
                    MessageBox.Show("Directory Not Found");
                }
            }
        }
    }
}
